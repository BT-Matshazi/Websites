<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include "layouts/header.php";

?>
<div id="page" class="hfeed site unyson-layout unyson-layout-snone">
    <a class="skip-link screen-reader-text" href="#content">Skip to content</a>

          <div class="entry-header-wrapper"
             style="background-image: url()">
            <div class="container">
                <header class="entry-header"><h1 class="page-title"><span>Coming Soon</span></h1>
    
                </header><!-- .entry-header -->
            </div>
        </div><!-- .entry-header-wrapper -->
    <div id="content" class="site-content">
    
        <div class="container">

            <div id="primary" class="content-area">
                <main id="main" class="site-main">
                    <div class="post-container snone">
                        <div class="row">
                            <div class="site__content col-xs-12">

                <div class="entry-content__inner">

<div class="entry-content">
  <div class="fw-page-builder-content"><section class="fw-main-row  bg-content-background "
     >
    <span class="bg-image-overlay bg-" style=" "></span>
    <div class="fw-container-fluid unyson_fullwidth">
            <div class="container has-container">
              <div class="row">
  <div class="col-md-12       " >
    <div style=" margin: ; padding: ;">
  

    <div class="fw-divider__space-30x  "></div>
    </div>
</div>
</div>

<div class="row">
  <div class="col-md-3       " >
    <div style=" margin: ; padding: ;">
  <p><img class="alignnone wp-image-165 size-full" src="<?php echo base_url(); ?>assets/images/404-img.jpg" width="231" height="239" /></p>

    <div class="fw-divider__space-10x  "></div>
    </div>
</div>
<div class="col-md-6       " >
    <div style=" margin: ; padding: ;">
  

    <div class="fw-divider__space-10x  "></div>


    <p>
        Coming Soon...
    <br><br>
  
    </p>

    
    <div class="fw-divider__space-10x  "></div>
    </div>
</div>
</div>
                    </div>
          </div>
</section>


</div>
    <div class="clear"></div>
</div><!-- .entry-content -->



</div><!-- .entry-content__inner -->                            </div>

              
                        </div>
                    </div>

                </main><!-- .site-main -->
            </div><!-- .content-area -->
        </div><!-- .container -->

    <!--tc: footer -->
<div id="to-top" class="to-top"><i class="fa fa-angle-up"></i></div>
</div><!-- .site-content -->



</div><!-- .site -->


<?php include "layouts/footer.php" ?>