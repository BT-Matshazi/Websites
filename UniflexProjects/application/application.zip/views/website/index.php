<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>

<!-- Mirrored from p.w3layouts.com/demos/flat_pricing_tables_design/web/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 14 Apr 2020 13:59:52 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<title>BrightBlack :: Website Packages </title> 
<link href="<?php echo base_url();?>assets/css/style.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Pricing Tables Design ,Flat Pricing Tables Design ,Pop up Pricing Tables Design,Clean Pricing Tables Design "./>
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
</script>
<script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
<!--webfonts-->
<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900,100italic,300italic,400italic,700italic' rel='stylesheet' type='text/css'>
<!--//webfonts-->

<!-- Favicon -->
    <link rel="icon" href="<?php echo base_url();?>assets/images/fav.png">
</head>

<body>
	<div class="col-sm-12">
		<a href="https://brightblack.africa/" target="_blank">
			<img src="<?php echo base_url(); ?>assets/images/bb_logo.png" style="max-width: 20%; padding: 20px;">
		</a>
	</div>
<script src="<?php echo base_url();?>assets/js/monetization.js" type="text/javascript"></script>
<script>
(function(){
	if(typeof _bsa !== 'undefined' && _bsa) {
  		// format, zoneKey, segment:value, options
  		_bsa.init('flexbar', 'CKYI627U', 'placement:w3layoutscom');
  	}
})();
</script>
<script>
(function(){
if(typeof _bsa !== 'undefined' && _bsa) {
	// format, zoneKey, segment:value, options
	_bsa.init('fancybar', 'CKYDL2JN', 'placement:demo');
}
})();
</script>
<script>
(function(){
	if(typeof _bsa !== 'undefined' && _bsa) {
  		// format, zoneKey, segment:value, options
  		_bsa.init('stickybox', 'CKYI653J', 'placement:w3layoutscom');
  	}
})();
</script>
<!--<script>(function(v,d,o,ai){ai=d.createElement("script");ai.defer=true;ai.async=true;ai.src=v.location.protocol+o;d.head.appendChild(ai);})(window, document, "//a.vdo.ai/core/w3layouts_V2/vdo.ai.js?vdo=34");</script>-->
<div id="codefund"><!-- fallback content --></div>
<script src="../../../../codefund.io/properties/441/funder.js" async="async"></script>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src='https://www.googletagmanager.com/gtag/js?id=UA-149859901-1'></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-149859901-1');
</script>

<script>
     window.ga=window.ga||function(){(ga.q=ga.q||[]).push(arguments)};ga.l=+new Date;
     ga('create', 'UA-149859901-1', 'demo.w3layouts.com');
     ga('require', 'eventTracker');
     ga('require', 'outboundLinkTracker');
     ga('require', 'urlChangeTracker');
     ga('send', 'pageview');
   </script>
<script async src='../../../js/autotrack.js'></script>

<meta name="robots" content="noindex">
<body><link rel="stylesheet" href="<?php echo base_url(); ?>assets/images/demobar_w3_4thDec2019.css">
	<!-- Demo bar start -->
<!--start-pricing-tablel-->
<script src="<?php echo base_url();?>assets/js/jquery.magnific-popup.js" type="text/javascript"></script>
		<script type="text/javascript" src="<?php echo base_url();?>assets/js/modernizr.custom.53451.js"></script> 

 <script>
						$(document).ready(function() {
						$('.popup-with-zoom-anim').magnificPopup({
							type: 'inline',
							fixedContentPos: false,
							fixedBgPos: true,
							overflowY: 'auto',
							closeBtnInside: true,
							preloader: false,
							midClick: true,
							removalDelay: 300,
							mainClass: 'my-mfp-zoom-in'
						});
																						
						});
				</script>							
 <div class="pricing-plans">
					 <div class="wrap">
					 	<div class="price-head">
					 		<h1>Website Design And Development Packages</h1>
							<!---728x90--->

					 	</div>
						<div class="pricing-grids">
						<div class="pricing-grid1">
							<div class="price-value">
									<h2><a href="#" id="packageName"> BASIC</a></h2>
									<h5><span id="packagePrice">R500</span> <label> / Year </label></h5>
									<input type="hidden" name="packageNameInput" value="BASIC">
									<div class="sale-box">
							<span class="on_sale title_shop">NEW</span>
							</div>

							</div>
							<div class="price-bg">
							<ul>
								<li class="whyt"><a href="#">Free .co.za domain</a></li>
								<li><a href="#">10 Email Boxes</a></li>
								<li><a href="#">3 Months Free Website Hosting</a></li>
								<li class="whyt"><a href="#">Free Email Forwarding </a></li>
								<li class="whyt"><a href="#">Full Support</a></li>
							</ul>
							<div class="cart1">
								<a class="popup-with-zoom-anim" href="#small-dialog" id="basic">Order</a>
							</div>
							</div>
						</div>
						<div class="pricing-grid2">
							<div class="price-value two">
								<h3><a href="#" id="packageName">STANDARD</a></h3>
								<h5><span>R700</span> <label> / Year </label></h5>
								<input type="hidden" name="packageNameInput" value="STANDARD">
								<div class="sale-box two">
							<span class="on_sale title_shop">NEW</span>
							</div>

							</div>
							<div class="price-bg">
							<ul>
								<li class="whyt"><a href="#">Free domain of choice</a></li>
								<li><a href="#">20 Email Boxes</a></li>
								<li><a href="#">6 Months Free Website Hosting</a></li>
								<li class="whyt"><a href="#">Free Email Forwarding </a></li>
								<li class="whyt"><a href="#">Full Support</a></li>
							</ul>
							<div class="cart2">
								<a class="popup-with-zoom-anim" href="#small-dialog" data-id="Basic Email Package" id="standard">Order</a>
							</div>
							</div>
						</div>
						<div class="pricing-grid3">
							<div class="price-value three">
								<h4><a href="#" id="packageName">CUSTOM</a></h4>
								<h5><span>Request Quote</span> <label> </label></h5>
								<input type="hidden" name="packageNameInput" value="PREMIUM">
								<div class="sale-box three">
							<span class="on_sale title_shop">NEW</span>
							</div>

							</div>
							<div class="price-bg">
							<ul>
								<li class="whyt"><a href="#">Free domain of choice</a></li>
								<li><a href="#">Unlimited Email Boxes</a></li>
								<li><a href="#">Free Website Hosting</a></li>
								<li class="whyt"><a href="#">Free Email Forwarding </a></li>
								<li class="whyt"><a href="#">Full Support</a></li>
							</ul>
							<div class="cart3">
								<a class="popup-with-zoom-anim" href="#small-dialog" id="premium">Order</a>
							</div>
							</div>
						</div>
							<div class="clear"> </div>
							<!--pop-up-grid-->
								 <div id="small-dialog" class="mfp-hide">
									<div class="pop_up">
									 	<div class="payment-online-form-left">
											<form id="placeOrder" action="Order" method="POST" class="contactform">
												<h4><span class="shipping"> </span>Place Order</h4>
												<h4 id="city_name"></h4>
												<input type="hidden" name="packageTitle" value="" id="packageTitle">
												<ul>
													<li><input name="fName" class="text-box-dark" type="text" placeholder="Frist Name" onfocus="this.value = '';" onblur="" required></li>
													<li><input name="lName" id="lName" class="text-box-dark" type="text" placehoder="Last Name" onfocus="this.value = '';" onblur="" required></li>
												</ul>
												<ul>
													<li><input name="emailAdd" id="emailAdd" class="text-box-dark" type="text" placeholder="Email" onfocus="this.value = '';" onblur=""></li>
													<li><input name="companyName" id="companyName" class="text-box-dark" type="text" placeholder="Company Name" onfocus="this.value = '';" onblur="" required></li>
												</ul>
												<ul>
													<li><input name="tel" id="tel" class="text-box-dark" type="text" placeholder="Phone" onfocus="this.value = '';" onblur="" requred></li>
													<li><input name="address" id="address" class="text-box-dark" type="text" placeholder="Address" onfocus="this.value = '';" onblur="" required></li>
													<div class="clear"> </div>
												</ul>
												<ul>
													<h2>Choose 2 Preferred Domain Names</h2>
												</ul>
												<ul>
													<li><input name="prefDomain" id="prefDomain" class="text-box-dark" type="text" placeholder="www.company.co.za" onfocus="this.value = '';" onblur=""></li>
													<li><input name="prefDomain2" id="prefDomain2" class="text-box-dark" type="text" placeholder="www.mycompany.co.za" onfocus="this.value = '';" onblur="" required></li>
												</ul>
												<div class="clear"> </div>
											<!-- <ul class="payment-type">
												<h4><span class="payment"> </span> Payments</h4>
												<li><span class="col_checkbox">
													<input id="3" class="css-checkbox1" type="checkbox">
													<label for="3" name="demo_lbl_1" class="css-label1"> </label>
													<a class="visa" href="#"> </a>
													</span>
													
												</li>
												<li>
													<span class="col_checkbox">
														<input id="4" class="css-checkbox2" type="checkbox">
														<label for="4" name="demo_lbl_2" class="css-label2"> </label>
														<a class="paypal" href="#"> </a>
													</span>
												</li>
												<div class="clear"> </div>
											</ul> -->
												<!-- <ul>
													<li><input class="text-box-dark" type="text" value="Card Number" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Card Number';}"></li>
													<li><input class="text-box-dark" type="text" value="Name on card" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Name on card';}"></li>
													<div class="clear"> </div>
												</ul> -->
												<!-- <ul>
													<li><input class="text-box-light hasDatepicker" type="text" id="datepicker" value="Expiration Date" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Expiration Date';}"><em class="pay-date"> </em></li>
													<li><input class="text-box-dark" type="text" value="Security Code" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Security Code';}"></li>
													<div class="clear"> </div>
												</ul> -->
												<ul class="payment-sendbtns">
													<li><input type="submit" value="Process order" id="orderBasic"></li>
												</ul>
												<div class="clear"> </div>
												<div class="col s12 m12 l8 xl8 form-message">
				                                    <span class="output_message center-align font-weight-500 uppercase"></span>
				                                </div>
											</form>
										</div>
						  			</div>
								</div>
								<!--pop-up-grid-->
							</div>
						<div class="clear"> </div>
					</div>
				
				</div>
	<!--//End-pricingplans-->
	<!---728x90--->

		<!-- /start-copyright-->
				<!-- <div class="footer">
					<div class="wrap">
						<p>&copy; 2020 <a href="https://brightblack.africa/" target="_blank" style="color: #000;">BrightBlack</a> .  All rights  reserved</p>
					</div>							
				</div> -->
		<!--//End-copyright-->
		<!---728x90--->

</body>

<!-- Mirrored from p.w3layouts.com/demos/flat_pricing_tables_design/web/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 14 Apr 2020 14:00:01 GMT -->
</html>		

<script type="text/javascript">
	//basic
	$(document).on("click", "#basic", function () {
   
	    $('#packageTitle').val('');
	    $("#city_name").text( 'BASIC - R500 Once Off' );
	    $('#packageTitle').val('BASIC - R500 Once Off');
	    
	});

	//standard
	$(document).on("click", "#standard", function () {
   
	    $('#packageTitle').val('');
	    $("#city_name").text( 'STANDARD - R700 Once Off' );
	    $('#packageTitle').val('STANDARD - R700 Once Off');
	    
	});

	//premium
	$(document).on("click", "#premium", function () {
   
	    $('#packageTitle').val('');
	    $("#city_name").text( 'PREMIUM - R1200 Once Off' );
	    $('#packageTitle').val('PREMIUM - R1200 Once Off');
	    
	});
	
   
   // place order
   $(".contactform").on("submit", function() {
        $(".output_message").text("Loading...");

        var form = $(this);
        $.ajax({

            url: form.attr("action"),
            method: form.attr("method"),
            data: form.serialize(),
            success: function(result) {
                if (result == "success") {
                    $(".contactform").find(".output_message").css({'color': '#3da10d'});
                    $('#orderBasic').hide();
                    $(".output_message").text("We have received your order!");

                } else {
                    $(".contactform").find(".output_message").css({'color': '#d93227'});
                    $(".output_message").text("There was a problem in processing your order!");
                    $('#orderBasic').hide();
                    
                }
            }
        });

        return false;
    });


	// });

</script>
