<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include "layouts/header.php";

?>
<div id="page" class="hfeed site unyson-layout unyson-layout-snone">
    <a class="skip-link screen-reader-text" href="#content">Skip to content</a>

	        <div class="entry-header-wrapper"
             style="background-image: url()">
            <div class="container">
                <header class="entry-header"><h1 class="page-title"><span>More About Us</span></h1>
	  
                </header><!-- .entry-header -->
            </div>
        </div><!-- .entry-header-wrapper -->
    <div id="content" class="site-content">
		
        <div class="container">

            <div id="primary" class="content-area">
                <main id="main" class="site-main">
                    <div class="post-container snone">
                        <div class="row">
                            <div class="site__content col-xs-12">

								<div class="entry-content__inner">

<div class="entry-content">
	<div class="fw-page-builder-content"><section class="fw-main-row  bg-content-background "
     >
    <span class="bg-image-overlay bg-" style=" "></span>
    <div class="fw-container-fluid unyson_fullwidth">
		        <div class="container has-container">
							<div class="row">
	<div class="col-md-12       " >
    <div style=" margin: ; padding: ;">
	

    <div class="fw-divider__space-30x  "></div>
    </div>
</div>
</div>

<div class="row">
	<div class="col-md-3       " >
    <div style=" margin: ; padding: ;">
	<p><img class="alignnone wp-image-165 size-full" src="<?php echo base_url(); ?>assets/images/md.png" width="231" height="239" /></p>

    <div class="fw-divider__space-10x  "></div>
    </div>
</div>
<div class="col-md-6       " >
    <div style=" margin: ; padding: ;">
	

    <div class="fw-divider__space-10x  "></div>

    <div class="fw-heading fw-heading--h2    fw-heading--alternate ">
			<h3 class='fw-special__title c-header-textcolor' style='font-weight: 900;color:'><span>UNIFLEX PROJECTS</span></h3>	
			
		</div>

    <div class="fw-divider__space-20x  "></div>
    <p>
        Uniflex Projects was founded in Johannesburg in February of 2009, as a close corporation. In 2011, the company was converted into a Privately Limited company, and has maintained steady and sustained growth in its participation and contribution in Southern African mining and industrial sectors.
        In it’s over ten years of operations, Uniflex Projects has undertaken several mining, industrial and construction capital equipment procurement projects in the region.:
    <br><br>
    <strong style="color: #333;">
        Engineering Equipment Procurement Projects – export supply and delivery of materials handling equipment such as Conveyor Belts, Discharge Pumps,  Mining  & Industrial Hose supplies for Zimbabwe’s largest mining, agricultural and industrial conglomerates.
    </strong><br><br>
    Materials Handling Equipment supply contracts – Slurry pumps and conveyor belt contracts with Zimbabwes largest gold, platinum, coal and diamond mines.<br><br>
     <strong style="color: #333;">
         Engineering Project Construction and Management – mine plant construction work in conveyor systems, steel pipe fabrication and industrial plumbing.
     </strong> <br><br>
     Materials handling equipment performance and maintenance audits and presentations – Conveyor Belts; Vibrating Feeders & Screens, Slurry Pumps
     <br><br>
     <strong style="color: #333;">
         Engineering design work for conveyor structures, frames and idler rollers from engineering drawings to manufacturing
     </strong> <br><br>
     In 2014, Uniflex Projects expanded into Zimbabwe by setting up a divisional sales offices in Harare  and Bulawayo under the name Uniflex Pumps & Rubber.

    </p>

    
    <div class="fw-divider__space-10x  "></div>
    </div>
</div>
<div class="col-md-3       " >
    <div style=" margin: ; padding: ;">
	

    <div class="fw-divider__space-10x  "></div>
<div class="fw-heading fw-heading--h5   fw-heading--with-subtitle fw-heading--alternate ">
			<h5 class='fw-special__title c-header-textcolor' style='font-weight:;color:'><span>Edward Battes</span></h5>	        <div class="fw-special__subtitle">Our Managing Director</div>
	</div>

    <div class="fw-divider__space-05x  "></div>
    </div>
</div>
</div>
				            </div>
			    </div>
</section>

<!-- <section class="fw-main-row  bg-content-background "
     >
    <span class="bg-image-overlay bg-" style=" "></span>
    <div class="fw-container-fluid unyson_fullwidth">
		        <div class="container has-container">
							<div class="row">
	<div class="col-md-12       " >
    <div style=" margin: ; padding: ;">
	

    <div class="fw-divider__space-10x  "></div>
    </div>
</div>
</div>

<div class="row">
	<div class="col-md-2       " >
    <div style=" margin: ; padding: ;">
	<a class="partner-link partner-link-single" href="http://webdesign-finder.com/oildrop" target="_blank"><img src="//webdesign-finder.com/oildrop/wp-content/uploads/2016/12/partner-1.png" alt="//webdesign-finder.com/oildrop/wp-content/uploads/2016/12/partner-1.png" /></a>

    <div class="fw-divider__space-10x  "></div>
    </div>
</div>
<div class="col-md-2       " >
    <div style=" margin: ; padding: ;">
	<a class="partner-link partner-link-single" href="http://webdesign-finder.com/oildrop" target="_blank"><img src="//webdesign-finder.com/oildrop/wp-content/uploads/2016/12/partner-2.png" alt="//webdesign-finder.com/oildrop/wp-content/uploads/2016/12/partner-2.png" /></a>

    <div class="fw-divider__space-10x  "></div>
    </div>
</div>
<div class="col-md-2       " >
    <div style=" margin: ; padding: ;">
	<a class="partner-link partner-link-single" href="http://webdesign-finder.com/oildrop" target="_blank"><img src="//webdesign-finder.com/oildrop/wp-content/uploads/2016/12/partner-3.png" alt="//webdesign-finder.com/oildrop/wp-content/uploads/2016/12/partner-3.png" /></a>

    <div class="fw-divider__space-10x  "></div>
    </div>
</div>
<div class="col-md-2       " >
    <div style=" margin: ; padding: ;">
	<a class="partner-link partner-link-single" href="http://webdesign-finder.com/oildrop" target="_blank"><img src="//webdesign-finder.com/oildrop/wp-content/uploads/2016/12/partner-5.png" alt="//webdesign-finder.com/oildrop/wp-content/uploads/2016/12/partner-5.png" /></a>

    <div class="fw-divider__space-10x  "></div>
    </div>
</div>
<div class="col-md-2       " >
    <div style=" margin: ; padding: ;">
	<a class="partner-link partner-link-single" href="http://webdesign-finder.com/oildrop" target="_blank"><img src="//webdesign-finder.com/oildrop/wp-content/uploads/2016/12/partner-4.png" alt="//webdesign-finder.com/oildrop/wp-content/uploads/2016/12/partner-4.png" /></a>

    <div class="fw-divider__space-10x  "></div>
    </div>
</div>
<div class="col-md-2       " >
    <div style=" margin: ; padding: ;">
	<a class="partner-link partner-link-single" href="http://webdesign-finder.com/oildrop" target="_blank"><img src="//webdesign-finder.com/oildrop/wp-content/uploads/2016/12/partner-6.png" alt="//webdesign-finder.com/oildrop/wp-content/uploads/2016/12/partner-6.png" /></a>

    <div class="fw-divider__space-10x  "></div>
    </div>
</div>
</div>

				            </div>
			    </div>
</section> -->
</div>
    <div class="clear"></div>
</div><!-- .entry-content -->



</div><!-- .entry-content__inner -->                            </div>

							
                        </div>
                    </div>

                </main><!-- .site-main -->
            </div><!-- .content-area -->
        </div><!-- .container -->

		<!--tc: footer -->
<div id="to-top" class="to-top"><i class="fa fa-angle-up"></i></div>
</div><!-- .site-content -->



</div><!-- .site -->


<?php include "layouts/footer.php" ?>