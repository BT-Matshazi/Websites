<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include "layouts/header.php";

?>

 <div id="page" class="hfeed site unyson-layout unyson-layout-snone">
    <a class="skip-link screen-reader-text" href="#content">Skip to content</a>

    <div class="entry-header-wrapper"
         style="background-image: url()">
        <div class="container">
            <header class="entry-header"><h1 class="page-title"><span>Products &amp; Services</span></h1>
	    <div class="breadcrumbs breadcrumbs-items-2">
					                <span class="first-item">
				                    <a href="http://webdesign-finder.com/oildrop/">Homepage</a></span>
				                <span class="separator separator-0">&gt;</span>
									                <span class="last-item">Thermal Power</span>
					    </div>
            </header><!-- .entry-header -->
        </div>
    </div><!-- .entry-header-wrapper -->


 <div class="container">

        <div id="primary" class="content-area">
            <main id="main" class="site-main">
                <div class="post-container snone">
                    <div class="row">

                        <div class="services-singular--content col-md-12 col-xs-12  ">                                <div id="post-382" class="entry-content post-382 fw-services type-fw-services status-publish has-post-thumbnail hentry">
									<div class="fw-page-builder-content"><section class="fw-main-row  "
    style="background-color:;background-position: center center center;background-repeat: no-repeat;background-attachment:scroll;background-size:cover;" >
    <span class="bg-image-overlay" style="background-color:; "></span>
    <div class="fw-container unyson_content">
		            <div class="container">
								<div class="row">
	<div class="col-md-12       " >
    <div style=" margin: ; padding: ;">
	

    <div class="fw-divider__space-30x  "></div>
    </div>
</div>
</div>

				        </div>
	    </div>
</section>
<section class="fw-main-row  "
    style="background-color:;background-position: center center center;background-repeat: no-repeat;background-attachment:scroll;background-size:cover;" >
    <span class="bg-image-overlay" style="background-color:; "></span>
    <div class="fw-container unyson_content">
		            <div class="container">
								<div class="row">
	<div class="    col-lg-3 col-md-4  " >
    <div style=" margin: ; padding: ;">
    	<h5 class="fw-special__title c-header-textcolor" style="font-weight:;color:"><span>Materials Handling Mastery</span></h5>
	<span class="unyson-media-image"><img src="<?php echo base_url(); ?>assets/images/materials.jpg" alt="Products & Services" width="" height="" /></span>

    <div class="fw-divider__space-10x  "></div>
    </div>
</div>


<!-- second row -->

<div class="    col-lg-9 col-md-8  " >
    <div style=" margin: ; padding: ;">
	<div class="fw-heading fw-heading--h2    fw-heading--alternate ">
			<h2 class="fw-special__title c-header-textcolor" style="font-weight: 900;"><span>Products</span></h2>	
			
		</div>    
<h5 class="fw-special__title c-header-textcolor" style="font-weight:;color:"><span>CONVEYOR  BELTS AND IDLER ROLLERS</span></h5>
<h6 class="fw-special__title" style="font-weight:;color:"><span>SLURRY PUMPS SPARES & VALVES
</span></h6>
<h5 class="fw-special__title c-header-textcolor" style="font-weight:;color:"><span>FLANGED HOSES & RUBBER MINING HOSE</span></h5>
<h6 class="fw-special__title" style="font-weight:;color:"><span>VIBRATING SCREENS, FEEDERS & DRIVES
</span></h6>
<h5 class="fw-special__title c-header-textcolor" style="font-weight:;color:"><span>MINE VENTILATION SYSTEMS
</span></h5>
<h6 class="fw-special__title" style="font-weight:;color:"><span>HDPE; PVC, STEEL & HYDRAULIC HOSES / PIPES & FITTINGS</span></h6>
	</div>
</div>

<div class="    col-lg-9 col-md-8  " >
    <div style=" margin: ; padding: ;">
	<div class="fw-heading fw-heading--h2    fw-heading--alternate ">
			<h2 class="fw-special__title c-header-textcolor" style="font-weight: 900;"><span>CORE SERVICES
</span></h2>	
			
		</div>    
<h5 class="fw-special__title c-header-textcolor" style="font-weight:;color:"><span>PROJECT MANAGEMENT & CONSULTANCY</span></h5>
<h6 class="fw-special__title" style="font-weight:;color:"><span>PIPE, PLANT & INFRASTRUCTURE CONSTRUCTION
</span></h6>
<h5 class="fw-special__title c-header-textcolor" style="font-weight:;color:"><span>BULK MATERIALS HANDLING EQUIPMENT  SURVEYS</span></h5>
<h6 class="fw-special__title" style="font-weight:;color:"><span>PROJECT PROCUREMENT, WAREHOUSING & FREIGHT LOGISTICS</span></h6>
<h5 class="fw-special__title c-header-textcolor" style="font-weight:;color:"><span>CONVEYOR BELT SPLICING, HDPE PIPE WELDING, HOSE CRIMPING</span></h5>
<h6 class="fw-special__title" style="font-weight:;color:"><span>VIBRATING SCREENS & GEARBOX REFURBISHMENTS</span></h6>
<h5 class="fw-special__title c-header-textcolor" style="font-weight:;color:"><span>CRANE & SCAFFOLDING HIRE</span></h5>
<h6 class="fw-special__title" style="font-weight:;color:"><span>CONVEYOR BELT TRIMMING & SPLICING</span></h6>
	</div>
</div>

<!-- image -->
<div class="    col-lg-3 col-md-4  " >
    <div style=" margin: ; padding: ;">
    	<h5 class="fw-special__title c-header-textcolor" style="font-weight:;color:"><span></span></h5>
	<span class="unyson-media-image"><img src="<?php echo base_url(); ?>assets/images/core.jpg" alt="Products & Services" width="" height="" /></span>

    <div class="fw-divider__space-10x  "></div>
    </div>
</div>

<!-- end second row -->
</div>


				        </div>
	    </div>
</section>
<!-- <section class="fw-main-row  "
    style="background-color:;background-position: center center center;background-repeat: no-repeat;background-attachment:scroll;background-size:cover;" >
    <span class="bg-image-overlay" style="background-color:; "></span>
    <div class="fw-container unyson_content">
		            <div class="container">
								<div class="row">
	<div class="col-md-12       " >
    <div style=" margin: ; padding: ;">
	<p>Prosciutto shoulder sirloin beef ribs fatback jerky. Turducken andouille pork loin, sausage tri-tip cow prosciutto hamburger fatback alcatra brisket ribeye pork belly swine. Ham porchetta prosciutto hamburger rump, cupim capicola sirloin tongue. Filet mignon pork chop venison spare ribs doner, picanha short loin pork belly frankfurter ham hock short ribs chicken cupim capicola. Chicken turkey boudin prosciutto, fatback swine turducken landjaeger tri-tip chuck pancetta flank.</p>    </div>
</div>
</div>

				        </div>
	    </div>
</section> -->
<section class="fw-main-row  "
    style="background-color:;background-position: center center center;background-repeat: no-repeat;background-attachment:scroll;background-size:cover;" >
    <span class="bg-image-overlay" style="background-color:; "></span>
    <div class="fw-container unyson_content">
		            <div class="container">
								<div class="row">
	<div class="col-md-12       " >
    <div style=" margin: ; padding: ;">
	

    <div class="fw-divider__space-30x  "></div>
    </div>
</div>
</div>

				        </div>
	    </div>
</section>
</div>
                                </div><!-- .entry-content -->                        </div><!-- .services-singular--content -->

						
                    </div><!-- .row -->
                </div><!-- .post-container -->

            </main><!-- .site-main -->
        </div><!-- .content-area -->
    </div><!-- .container -->

<!--tc: footer -->
<div id="to-top" class="to-top"><i class="fa fa-angle-up"></i></div>
</div><!-- .site-content -->



</div><!-- .site -->

<?php include "layouts/footer.php" ?>