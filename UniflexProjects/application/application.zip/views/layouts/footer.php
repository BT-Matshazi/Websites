<div class="fw-divider__space-10x  "></div>
<section class="fw-main-row  bg-content-background "
     >
    <span class="bg-image-overlay bg-" style=" "></span>
    <div class="fw-container-fluid unyson_fullwidth">
		        <div class="container has-container">
							<div class="row">
	<div class="col-md-12       " >
    <div style=" margin: ; padding-top: 30px;">
	
	<div class="fw-heading fw-heading--h2    fw-heading--alternate ">
			<h6 class='fw-special__title c-header-textcolor' style='font-weight: 900;color:'><span>Our Partners</span></h6>	
			
		</div>

    <div class="fw-divider__space-10x  "></div>
    </div>
</div>
</div>

<div class="row">
    <!-- Kwatani -->
	<div class="col-md-2" >
        <div style=" margin: ; padding: ;">
    	   <a class="partner-link partner-link-single" href="javascript:void(0)" target=""><img src="<?php echo base_url(); ?>assets/images/partners/kwatani.png" alt="Kwatani" /></a>

        <div class="fw-divider__space-10x  "></div>
        </div>

    </div>

    <!-- buccaneer -->
    <div class="col-md-2" >
        <div style=" margin: ; padding: ;">
           <a class="partner-link partner-link-single" href="javascript:void(0)" target=""><img src="<?php echo base_url(); ?>assets/images/partners/buccaneer.png" alt="Buccaneer Slurry Pumps" /></a>

        <div class="fw-divider__space-10x  "></div>
        </div>

    </div>

    <!-- Interflex -->
    <div class="col-md-2" >
        <div style=" margin: ; padding: ;">
           <a class="partner-link partner-link-single" href="javascript:void(0)" target=""><img src="<?php echo base_url(); ?>assets/images/partners/interflex.png" alt="Interflex Conveyor Belting" /></a>

        <div class="fw-divider__space-10x  "></div>
        </div>

    </div>

    <!-- UNIQUE VENTILATION & SUPPORT SYSTEMS -->

    <div class="col-md-2" >
        <div style=" margin: ; padding: ;">
           <a class="partner-link partner-link-single" href="javascript:void(0)" target=""><img src="<?php echo base_url(); ?>assets/images/partners/unique.png" alt="UNIQUE VENTILATION & SUPPORT SYSTEMS" /></a>

        <div class="fw-divider__space-10x  "></div>
        </div>

    </div>

</div>

				            </div>
			    </div>
</section>
<!-- footer -->
<footer style="padding-bottom: 20px;">
	<div class="container">
		<div class="copyright">
                        <div class="container">
                            <div class="row copyright-row">
								                                    <div class="copyright-social col-sm-12">
	                                    
              
                                                </div>
								                                <div class="copyright-text col-sm-12" style="color: #ea822d;">© 2020 Uniflex Projects<span class="rt-icon"></span> by <a href="https://brightblack.africa/" target="_blank" style="color: #000;">BrightBlack</a></div>
                            </div>
                        </div>
                    </div>
	</div>
</footer>

		<script>(function() {function addEventListener(element,event,handler) {
	if(element.addEventListener) {
		element.addEventListener(event,handler, false);
	} else if(element.attachEvent){
		element.attachEvent('on'+event,handler);
	}
}function maybePrefixUrlField() {
	if(this.value.trim() !== '' && this.value.indexOf('http') !== 0) {
		this.value = "http://" + this.value;
	}
}

var urlFields = document.querySelectorAll('.mc4wp-form input[type="url"]');
if( urlFields && urlFields.length > 0 ) {
	for( var j=0; j < urlFields.length; j++ ) {
		addEventListener(urlFields[j],'blur',maybePrefixUrlField);
	}
}/* test if browser supports date fields */
var testInput = document.createElement('input');
testInput.setAttribute('type', 'date');
if( testInput.type !== 'date') {

	/* add placeholder & pattern to all date fields */
	var dateFields = document.querySelectorAll('.mc4wp-form input[type="date"]');
	for(var i=0; i<dateFields.length; i++) {
		if(!dateFields[i].placeholder) {
			dateFields[i].placeholder = 'YYYY-MM-DD';
		}
		if(!dateFields[i].pattern) {
			dateFields[i].pattern = '[0-9]{4}-(0[1-9]|1[012])-(0[1-9]|1[0-9]|2[0-9]|3[01])';
		}
	}
}

})();</script>	<script type="text/javascript">
		var c = document.body.className;
		c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
		document.body.className = c;
	</script>
				<script type="text/javascript">
				function revslider_showDoubleJqueryError(sliderID) {
					var errorMessage = "Revolution Slider Error: You have some jquery.js library include that comes after the revolution files js include.";
					errorMessage += "<br> This includes make eliminates the revolution slider libraries, and make it not work.";
					errorMessage += "<br><br> To fix it you can:<br>&nbsp;&nbsp;&nbsp; 1. In the Slider Settings -> Troubleshooting set option:  <strong><b>Put JS Includes To Body</b></strong> option to true.";
					errorMessage += "<br>&nbsp;&nbsp;&nbsp; 2. Find the double jquery.js include and remove it.";
					errorMessage = "<span style='font-size:16px;color:#BC0C06;'>" + errorMessage + "</span>";
						jQuery(sliderID).show().html(errorMessage);
				}
			</script>
			<script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"http:\/\/webdesign-finder.com\/oildrop\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"recaptcha":{"messages":{"empty":"Please verify that you are not a robot."}}};
/* ]]> */
</script>
<script type='text/javascript' src='http://webdesign-finder.com/oildrop/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.0.5'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var script_params = {"ajax_url":"http:\/\/webdesign-finder.com\/oildrop\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='http://webdesign-finder.com/oildrop/wp-content/plugins/custom-content-team/inc/../js/team.js?ver=1'></script>
<script type='text/javascript' src='http://webdesign-finder.com/oildrop/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.tools.min.js?ver=5.4.8'></script>
<script type='text/javascript' src='http://webdesign-finder.com/oildrop/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.revolution.min.js?ver=5.4.8'></script>
<script type='text/javascript' src='http://webdesign-finder.com/oildrop/wp-content/plugins/revslider/public/assets/js/extensions/revolution.extension.actions.min.js?ver=5.4.8'></script>
<script type='text/javascript' src='http://webdesign-finder.com/oildrop/wp-content/plugins/revslider/public/assets/js/extensions/revolution.extension.carousel.min.js?ver=5.4.8'></script>
<script type='text/javascript' src='http://webdesign-finder.com/oildrop/wp-content/plugins/revslider/public/assets/js/extensions/revolution.extension.kenburn.min.js?ver=5.4.8'></script>
<script type='text/javascript' src='http://webdesign-finder.com/oildrop/wp-content/plugins/revslider/public/assets/js/extensions/revolution.extension.layeranimation.min.js?ver=5.4.8'></script>
<script type='text/javascript' src='http://webdesign-finder.com/oildrop/wp-content/plugins/revslider/public/assets/js/extensions/revolution.extension.migration.min.js?ver=5.4.8'></script>
<script type='text/javascript' src='http://webdesign-finder.com/oildrop/wp-content/plugins/revslider/public/assets/js/extensions/revolution.extension.navigation.min.js?ver=5.4.8'></script>
<script type='text/javascript' src='http://webdesign-finder.com/oildrop/wp-content/plugins/revslider/public/assets/js/extensions/revolution.extension.parallax.min.js?ver=5.4.8'></script>
<script type='text/javascript' src='http://webdesign-finder.com/oildrop/wp-content/plugins/revslider/public/assets/js/extensions/revolution.extension.slideanims.min.js?ver=5.4.8'></script>
<script type='text/javascript' src='http://webdesign-finder.com/oildrop/wp-content/plugins/revslider/public/assets/js/extensions/revolution.extension.video.min.js?ver=5.4.8'></script>
<script type='text/javascript' src='http://webdesign-finder.com/oildrop/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.70'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/oildrop\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/oildrop\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"http:\/\/webdesign-finder.com\/oildrop\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='http://webdesign-finder.com/oildrop/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=3.5.2'></script>
<script type='text/javascript' src='http://webdesign-finder.com/oildrop/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/oildrop\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/oildrop\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='http://webdesign-finder.com/oildrop/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=3.5.2'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/oildrop\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/oildrop\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_20896974b6218dc447326e55901baa85","fragment_name":"wc_fragments_20896974b6218dc447326e55901baa85"};
/* ]]> */
</script>
<script type='text/javascript' src='http://webdesign-finder.com/oildrop/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=3.5.2'></script>
<script type='text/javascript' src='http://webdesign-finder.com/oildrop/wp-content/themes/oildrop/vendors/vendors.min.js?ver=all'></script>
<script type='text/javascript' src='http://webdesign-finder.com/oildrop/wp-content/themes/oildrop/js/theme.js?ver=all'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var MyAjax = {"ajaxurl":"http:\/\/webdesign-finder.com\/oildrop\/wp-admin\/admin-ajax.php","security":"ffdce4a9d1"};
/* ]]> */
</script>
<script type='text/javascript' src='http://webdesign-finder.com/oildrop/wp-content/themes/oildrop/includes/mods/mod-post-likes/mod-post-likes.js?ver=1.0.0'></script>
<script type='text/javascript' src='http://webdesign-finder.com/oildrop/wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/js/core.js?ver=4.9.14'></script>
<script type='text/javascript' src='http://webdesign-finder.com/oildrop/wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/js/transition.js?ver=4.9.14'></script>
<script type='text/javascript' src='http://webdesign-finder.com/oildrop/wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/js/background.js?ver=4.9.14'></script>
<script type='text/javascript' src='http://webdesign-finder.com/oildrop/wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/js/background.init.js?ver=4.9.14'></script>
<script type='text/javascript' src='https://maps.googleapis.com/maps/api/js?v=3.23&#038;language=en&#038;libraries=places&#038;key=AIzaSyC0pr5xCHpaTGv12l73IExOHDJisBP2FK4&#038;ver=3.23'></script>
<script type='text/javascript' src='http://webdesign-finder.com/oildrop/wp-includes/js/underscore.min.js?ver=1.8.3'></script>
<script type='text/javascript' src='http://webdesign-finder.com/oildrop/wp-content/themes/oildrop/framework-customizations/extensions/shortcodes/shortcodes/map/static/js/scripts.js?ver=2.7.20'></script>
<script type='text/javascript' src='http://webdesign-finder.com/oildrop/wp-includes/js/wp-embed.min.js?ver=4.9.14'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var mc4wp_forms_config = [];
/* ]]> */
</script>
<script type='text/javascript' src='http://webdesign-finder.com/oildrop/wp-content/plugins/mailchimp-for-wp/assets/js/forms-api.min.js?ver=4.3.1'></script>
<!--[if lte IE 9]>
<script type='text/javascript' src='http://webdesign-finder.com/oildrop/wp-content/plugins/mailchimp-for-wp/assets/js/third-party/placeholders.min.js?ver=4.3.1'></script>
<![endif]-->
<script>var htmlDiv = document.getElementById("rs-plugin-settings-inline-css"); var htmlDivCss=".tp-caption.oildrop_category,.oildrop_category{color:rgba(255,255,255,1.00);font-size:14px;line-height:23px;font-weight:700;font-style:normal;font-family:Kanit;text-decoration:none;background-color:transparent;border-color:transparent;border-style:none;border-radius:0px 0px 0px 0px}.tp-caption.oildrop_title,.oildrop_title{color:rgba(255,255,255,1.00);font-size:88px;line-height:83px;font-weight:700;font-style:normal;font-family:Roboto;text-decoration:none;background-color:transparent;border-color:transparent;border-style:none;border-radius:0px 0px 0px 0px}.tp-caption.oildrop_text,.oildrop_text{color:rgba(138,227,255,1.00);font-size:17px;line-height:23px;font-weight:700;font-style:normal;font-family:Arial;text-decoration:none;background-color:transparent;border-color:transparent;border-style:none;border-radius:0px 0px 0px 0px}";
				if(htmlDiv) {
					htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
				}else{
					var htmlDiv = document.createElement("div");
					htmlDiv.innerHTML = "<style>" + htmlDivCss + "</style>";
					document.getElementsByTagName("head")[0].appendChild(htmlDiv.childNodes[0]);
				}
			</script>
		<script type="text/javascript">
if (setREVStartSize!==undefined) setREVStartSize(
	{c: '#rev_slider_1_1', responsiveLevels: [1240,1024,778,480], gridwidth: [1200,970,750,320], gridheight: [740,500,500,320], sliderLayout: 'auto'});
			
var revapi1,
	tpj;	
(function() {			
	if (!/loaded|interactive|complete/.test(document.readyState)) document.addEventListener("DOMContentLoaded",onLoad); else onLoad();	
	function onLoad() {				
		if (tpj===undefined) { tpj = jQuery; if("off" == "on") tpj.noConflict();}
	if(tpj("#rev_slider_1_1").revolution == undefined){
		revslider_showDoubleJqueryError("#rev_slider_1_1");
	}else{
		revapi1 = tpj("#rev_slider_1_1").show().revolution({
			sliderType:"standard",
			jsFileLocation:"//webdesign-finder.com/oildrop/wp-content/plugins/revslider/public/assets/js/",
			sliderLayout:"auto",
			dottedOverlay:"none",
			delay:9000,
			navigation: {
				keyboardNavigation:"off",
				keyboard_direction: "horizontal",
				mouseScrollNavigation:"off",
 							mouseScrollReverse:"default",
				onHoverStop:"off",
				touch:{
					touchenabled:"on",
					touchOnDesktop:"off",
					swipe_threshold: 75,
					swipe_min_touches: 1,
					swipe_direction: "horizontal",
					drag_block_vertical: false
				}
				,
				arrows: {
					style:"custom",
					enable:true,
					hide_onmobile:true,
					hide_under:1000,
					hide_onleave:false,
					tmp:'',
					left: {
						h_align:"left",
						v_align:"center",
						h_offset:20,
						v_offset:0
					},
					right: {
						h_align:"right",
						v_align:"center",
						h_offset:20,
						v_offset:0
					}
				}
				,
				bullets: {
					enable:true,
					hide_onmobile:false,
					style:"custom",
					hide_onleave:false,
					direction:"horizontal",
					h_align:"center",
					v_align:"bottom",
					h_offset:0,
					v_offset:20,
					space:10,
					tmp:''
				}
			},
			viewPort: {
				enable:true,
				outof:"wait",
				visible_area:"80%",
				presize:false
			},
			responsiveLevels:[1240,1024,778,480],
			visibilityLevels:[1240,1024,778,480],
			gridwidth:[1200,970,750,320],
			gridheight:[740,500,500,320],
			lazyType:"none",
			parallax: {
				type:"scroll",
				origo:"enterpoint",
				speed:400,
				speedbg:0,
				speedls:0,
				levels:[5,10,15,20,25,30,35,40,45,46,47,48,49,50,51,55],
			},
			shadow:0,
			spinner:"off",
			stopLoop:"on",
			stopAfterLoops:2,
			stopAtSlide:1,
			shuffle:"off",
			autoHeight:"off",
			hideThumbsOnMobile:"off",
			hideSliderAtLimit:0,
			hideCaptionAtLimit:993,
			hideAllCaptionAtLilmit:0,
			startWithSlide:0,
			debugMode:false,
			fallbacks: {
				simplifyAll:"off",
				nextSlideOnWindowFocus:"off",
				disableFocusListener:false,
			}
		});
	}; /* END OF revapi call */
	
 }; /* END OF ON LOAD FUNCTION */
}()); /* END OF WRAPPING FUNCTION */
</script>
		<script>
jQuery( document ).ready( function($) {
        $('#more_info').hide();

	$('.bawpvc-ajax-counter').each( function( i ) {
		var $id = $(this).data('id');
		var t = this;
		var n = 0;
		$.get('http://webdesign-finder.com/oildrop/wp-admin/admin-ajax.php?action=bawpvc-ajax-counter&p='+$id+'&n='+n, function( html ) {
			$(t).html( html );
		})
	});
});
</script>
<!--tc: /wp_footer -->
<!--tc: /footer -->
</body>
</html>
<!--/tc: page.php -->