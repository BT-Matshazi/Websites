<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html lang="en-US" class="no-js">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <link rel="pingback" href="http://webdesign-finder.com/oildrop/xmlrpc.php">
	<title> Define | Design | Deliver </title>
<meta name='robots' content='noindex,follow' />
<link rel='dns-prefetch' href='//maps.googleapis.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="OilDrop &raquo; Feed" href="http://webdesign-finder.com/oildrop/feed/" />
<link rel="alternate" type="application/rss+xml" title="OilDrop &raquo; Comments Feed" href="http://webdesign-finder.com/oildrop/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/webdesign-finder.com\/oildrop\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.14"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56760,9792,65039],[55358,56760,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='contact-form-7-css'  href='<?php echo base_url(); ?>assets/css/contact_form.css' type='text/css' media='all' />
<link rel='stylesheet' id='cct-team-css'  href='<?php echo base_url(); ?>assets/css/team.css' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='<?php echo base_url(); ?>assets/css/settings.css' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<link rel='stylesheet' id='woocommerce-layout-css'  href='<?php echo base_url(); ?>assets/css/woocommerce-layout.css' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce-smallscreen-css'  href='<?php echo base_url(); ?>assets/css/woocommerce-smallscreen.css' type='text/css' media='only screen and (max-width: 768px)' />
<link rel='stylesheet' id='woocommerce-general-css'  href='<?php echo base_url(); ?>assets/css/woocommerce.css' type='text/css' media='all' />
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='oildrop-fonts-css'  href='//fonts.googleapis.com/css?family=Open+Sans%3A300%2C300italic%2C400%2C400italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%7CRoboto%3A400%2C400i%2C500%2C500i%2C700%2C700i%2C900%7CKanit%3A400%2C400i%2C700%2C700i&#038;subset=latin%2Clatin-ext' type='text/css' media='all' />
<link rel='stylesheet' id='oildrop-vendors-css'  href='<?php echo base_url(); ?>assets/css/vendors.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='fw-ext-forms-default-styles-css'  href='<?php echo base_url(); ?>assets/css/frontend.css' type='text/css' media='all' />
<link rel='stylesheet' id='fw-shortcode-section-background-video-css'  href='<?php echo base_url(); ?>assets/css/background.css' type='text/css' media='all' />
<link rel='stylesheet' id='fw-shortcode-section-css'  href='<?php echo base_url(); ?>assets/css/styles1.css' type='text/css' media='all' />
<link rel='stylesheet' id='oildrop-theme-css'  href='<?php echo base_url(); ?>assets/css/theme.css' type='text/css' media='all' />
<link rel='stylesheet' id='oildrop-unyson-css'  href='<?php echo base_url(); ?>assets/css/unyson.css' type='text/css' media='all' />
<link rel='stylesheet' id='oildrop-style-css'  href='<?php echo base_url(); ?>assets/css/style3.css' type='text/css' media='all' />
<link rel="icon" href="<?php echo base_url(); ?>assets/images/32x31.png" sizes="" />
<style id='oildrop-style-inline-css' type='text/css'>
	/* Color Scheme */
	
	
	.c-header-textcolor     { color: #ea822d; }
	.bg-header-textcolor    { background-color: #ea822d; }
	.brd-header-textcolor   { border-color: #ea822d; }
	
	.c-background-color     { color: #ecedef; }
	.bg-background-color    { background-color: #ecedef; }
	.brd-background-color   { border-color: #ecedef; }
	
	.c-content-background   { color: #ffffff; }
	.bg-content-background  { background-color: #ffffff; }
	.brd-content-background { border-color: #ffffff; }
	
	.c-content-textcolor    { color: ; }
	.bg-content-textcolor   { background-color: ; }
	.brd-content-textcolor  { border-color: ; }
	
	.c-accent-color         { color: #b5b5b5; }
	.bg-accent-color        { background-color: #b5b5b5; }
	.brd-accent-color       { border-color: #b5b5b5; }
	
	.c-accent-color-2       { color: #ea822d; }
	.bg-accent-color-2      { background-color: #ea822d; }
	.brd-accent-color-2     { border-color: #ea822d; }
	

	/** 
	 * Header Textcolor
	 * ----------------
	 */
	 
	h1, h2, h3, h4, h5, h6,
	.widget-title,
	.entry-header-wrapper .page-title,
	.post__inner > h2 > a,
	.fw-iconbox--left .fw-iconbox__title h3,
	.fw-iconbox--top .fw-iconbox__title h3,
	.fw-iconbox--left .fw-iconbox__title h3 a,
	.fw-iconbox--top .fw-iconbox__title h3 a,
	.recent-posts__title,
	.fw-testimonials__name,
	.oildrop-getaquote h2,
	.fw-iconbox--left .fw-iconbox__text strong,
	.fw-iconbox--left .fw-iconbox__text span,
	.fw-package .fw-heading-row span,
	.fw-skills-bar .progress-title, .fw-skills-bar .progress-level,
	blockquote cite,
	blockquote cite a,
	.page_title_404,
	.front-posts-layout--1col .entry-title, 
	.front-posts-layout--1colws .entry-title,
	.front-posts-layout--1colwsl .entry-title,
	.front-posts-layout--1col .entry-title a,
	.front-posts-layout--1colws .entry-title a,
	.front-posts-layout--1colwsl .entry-title a,
	.format-link .the-content a,
	.chat-transcript .chat-row.chat-speaker-2 .chat-author,
	.widget_recent_comments li a,
	.portfolio--alternate .portfolio__title a, .portfolio--extended .portfolio__title a,
	.fw-team .fw-team__name a,
	.member-team-wrapper #cctContactForm ul li label,
	.woocommerce ul.cart_list li a, .woocommerce ul.product_list_widget li a,
	.woocommerce ul.products li.product h3
	{
		color: #ea822d;
	}
	.title-block .title,
	.title-block .sub
	{
		color: #ea822d !important;
	}
	
	
	/** 
	 * Site Background
	 * ---------------
	 */
	
	/*.fw-container,*/
	/*.unyson_content,*/
	/*.bg-image-overlay,*/
	#primary,
	.content-area,
	.entry-content,
	.site-content,
	.error404 .site-content,
	.entry-content__inner,
	.fw-page-builder-content,
	body,
	#preloader,
	{
		background-color: #ecedef !important;
	}
	
	.fw-accordion__title a.collapsed,
	
	input, textarea,
	
	.section-dark-bg .oildrop-getaquote input[type="text"],
	.section-dark-bg .oildrop-getaquote input[type="email"],
	.section-dark-bg .oildrop-getaquote input[type="tel"],
	.section-dark-bg .oildrop-getaquote input[type="number"],
	.section-dark-bg .oildrop-getaquote input[type="url"],
	.section-dark-bg .oildrop-getaquote input[type="password"],
	.section-dark-bg .oildrop-getaquote input[type="search"],
	.section-dark-bg .oildrop-getaquote input[type="date"],
	.section-dark-bg .oildrop-getaquote input[type="time"],
	.section-dark-bg .oildrop-getaquote input[type="datetime-local"],
	.section-dark-bg .oildrop-getaquote input[type="month"],
	.section-dark-bg .oildrop-getaquote textarea
	
	{
		background-color: #ecedef;
	}
	
	input, textarea
	{
		border-color: #ecedef;
	}
	
	
	/** 
	 * Content Background
	 * ---------------
	 */
	 
	.section-dark-bg input[type="text"],
	.section-dark-bg input[type="email"],
	.section-dark-bg input[type="tel"],
	.section-dark-bg input[type="number"],
	.section-dark-bg input[type="url"],
	.section-dark-bg input[type="password"],
	.section-dark-bg input[type="search"],
	.section-dark-bg input[type="date"],
	.section-dark-bg input[type="time"],
	.section-dark-bg input[type="datetime-local"],
	.section-dark-bg input[type="month"],
	.section-dark-bg textarea,
	
	.layout-3 .recent-posts__content,
	.error404 .site-content,
	.entry-content .col-content,
	.format-video .entry-content,
	.format-link .entry-content,
	.post__inner,
	.secondary input, .secondary textarea,
	.widget_product_tag_cloud .tagcloud a, .widget_tag_cloud .tagcloud a,
	.single-fw-portfolio .entry-content__inner,
	.tax-fw-services-category .site-content, .post-type-archive-fw-services .site-content,
	.single-fw-services .site-content,
	.tax-team_category .content-area,
	.post-type-archive-team_member .content-area,
	.single-team_member .content-area,
	.oildrop-getaquote,
	.page .entry-content__inner,
	.fw-action,
	.woocommerce .site-content
	{
		background-color: #ffffff;
	}	
	@media screen and (min-width: 768px) {
		.single-post .entry-content__inner {
		    background-color: #ffffff;
		}
	}
	.secondary input, .secondary textarea
	{
		border-color: #ffffff;
	}
	
	
	/** 
	 * Content Textcolor
	 * -----------------
	 */
	
    body,
    caption,
    /*.social-navigation a,*/ /* cause: bad hover effect in footer socials */
     .social-navigation a::before,
    .woocommerce div.product span.price del,
    .woocommerce div.product p.price del,
    .woocommerce div.product .woocommerce-tabs ul.tabs > li > a,
    .woocommerce ul.products li.product .price del,
    .woocommerce nav.woocommerce-pagination ul li span.current,
    .woocommerce nav.woocommerce-pagination ul li a:hover,
    .woocommerce nav.woocommerce-pagination ul li a:focus,
    .woocommerce a.button.alt.disabled, .woocommerce a.button.alt:disabled, .woocommerce a.button.alt:disabled[disabled],
    .woocommerce a.button.alt.disabled:hover, .woocommerce a.button.alt:disabled:hover,
    .woocommerce a.button.alt:disabled[disabled]:hover,
    .woocommerce button.button.alt.disabled,
    .woocommerce button.button.alt:disabled,
    .woocommerce button.button.alt:disabled[disabled],
    .woocommerce button.button.alt.disabled:hover,
    .woocommerce button.button.alt:disabled:hover,
    .woocommerce button.button.alt:disabled[disabled]:hover,
    .woocommerce input.button.alt.disabled,
    .woocommerce input.button.alt:disabled,
    .woocommerce input.button.alt:disabled[disabled],
    .woocommerce input.button.alt.disabled:hover,
    .woocommerce input.button.alt:disabled:hover,
    .woocommerce input.button.alt:disabled[disabled]:hover,
    .woocommerce #respond input#submit.alt.disabled,
    .woocommerce #respond input#submit.alt:disabled,
    .woocommerce #respond input#submit.alt:disabled[disabled],
    .woocommerce #respond input#submit.alt.disabled:hover,
    .woocommerce #respond input#submit.alt:disabled:hover,
    .woocommerce #respond input#submit.alt:disabled[disabled]:hover,
    .woocommerce-message,
    .woocommerce-error,
    .woocommerce-info,
    
    .page_message_404,
    .format-quote .entry-content .post-content blockquote small,
    .format-aside .entry-content .entry-title + .posted-on,
    .format-aside .entry-content .entry-title + .posted-on a,
    .format-status .entry-content .post-content--status,
    .format-status .entry-content .post-content--status + .posted-on,
    .fw-iconbox--left .fw-iconbox__text,
    .fw-listbox a,
    .widget_nav_menu li a,
    .footer .widget a
	{
	    color: ;
	}

    ::-webkit-input-placeholder {
      color: ;
    }
    
    :-moz-placeholder {
      color: ;
    }
    
    ::-moz-placeholder {
      color: ;
    }
    
    :-ms-input-placeholder {
      color: ;
    }
	
	
/**
 * Accent Color
 * ------------
 */

#preloader-status {
  color: #b5b5b5;
}
	
.fw-theme-bg-color-1 {
  background-color: #b5b5b5;
}
.fw-theme-color-1 {
  color: #b5b5b5;
}
.spinner > div {
  background-color: #b5b5b5;
}
@-webkit-keyframes stretchdelay {
  0%,
  40%,
  100% {
    -webkit-transform: scaleY(0.4);
    background-color: #b5b5b5;
  }
  20% {
    -webkit-transform: scaleY(1);
    background-color: #ea822d;
  }
}
@keyframes stretchdelay {
  0%,
  40%,
  100% {
    transform: scaleY(0.4);
    -webkit-transform: scaleY(0.4);
    background-color: #b5b5b5;
  }
  20% {
    transform: scaleY(1);
    -webkit-transform: scaleY(1);
    background-color: #ea822d;
  }
}
.page .entry-content__inner {
  border-bottom-color: #b5b5b5;
}
.title-colored .h1, .title-colored h1,
.title-colored .h2, .title-colored h2,
.title-colored .h3, .title-colored h3,
.title-colored .h4, .title-colored h4,
.title-colored .h5, .title-colored h5,
.title-colored .h6, .title-colored h6 {
  color: #b5b5b5;
}
b,
strong {
  color: #b5b5b5; /*light blue (see section 'Feedback' on main page) */
}
blockquote {
  border-left-color: #b5b5b5;
}
acronym,
abbr[title] {
  border-bottom-color: #b5b5b5;
}
/* Dropcaps */
body.dropcaps1:not(.home):not(.blog):not(.archive) .entry-content > .page-title + p:first-letter,
body.dropcaps1:not(.home):not(.blog):not(.archive) .entry-content > p:first-child:first-letter,
body.dropcaps1:not(.home):not(.blog):not(.archive) .entry-content .post__inner .post-content > p:first-child:first-letter,
p.dropcaps1:first-letter {
  color: #b5b5b5;
}

.btn,
.button,
button,
input[type="button"],
input[type="reset"],
input[type="submit"] {
  background-color: #b5b5b5;
}
a:hover, a:focus, a:active,
a:hover strong,
a:focus strong,
a:active strong {
  color: #b5b5b5;
}
strong a {
  color: #b5b5b5; /*light blue (see section 'Feedback' on main page) */
}
a strong {
    color: #b5b5b5; /*light blue (see section 'Feedback' on main page) */
}
.excerpt-more .more-link {
  color: #b5b5b5;
}	
.create-menu a:hover, .create-menu a:focus {
  color: #b5b5b5;
}
.main-nav ul li a:focus, .main-nav ul li a:hover {
  color: #b5b5b5;
}
.main-nav ul li ul {
  border-color: #b5b5b5;
}
.main-nav ul li ul li a:focus, .main-nav ul li ul li a:hover {
  color: #b5b5b5;
}
.main-nav > ul > li.marked a {
  background-color: #b5b5b5;
}
.header__style2 .main-nav > ul > li.marked a:hover, .header__style2 .main-nav > ul > li.marked a:focus {
  color: #b5b5b5;
}
.social-navigation a:hover, .social-navigation a:hover::before {
  color: #b5b5b5;
}
.post-navigation .meta-nav {
  color: #b5b5b5;
}
.pagination .current,
.pagination a:hover,
.pagination a:focus {
  color: #b5b5b5;
}
.page-links > span:not(.page-links-title),
.page-links .current,
.page-links a:hover,
.page-links a:focus {
  color: #b5b5b5;
}
.site .skip-link {
  color: #b5b5b5;
}

.header__row1 a:hover, .header__row1 a:focus {
  color: #b5b5b5;
}

.header__row3 {
  background-color: #b5b5b5;
}
.header__row3 a:hover,
.header__row3 a:focus {
  color: #b5b5b5;
}
a.header__contact-item-btn {
  color: #b5b5b5;
}
.header__row3 a.header__contact-item-btn {
  color: #b5b5b5 !important;
}

.widget_calendar .calendar__navigation,
.widget_calendar #wp-calendar th#today,
.widget_calendar #wp-calendar td#today,
.posts-slider__category a,
.woocommerce .widget_price_filter .ui-slider .ui-slider-handle,
.woocommerce .widget_price_filter .ui-slider .ui-slider-range,
.front-posts-layout--2col .post__media,
.front-posts-layout--2colws .post__media,
.front-posts-layout--2colwsl .post__media,
.search .entry-content .post__media,
.archive .entry-content .post__media,
.single .post-thumbnail,
.homepage_link a,
.single .featured-media.status-wrap,
.format-video .post__media,
.single-format-video .post__media,
.format-image .post__media a.post-thumbnail,
.format-gallery .post__media .gallery,
.single-format-gallery .post__media .gallery,
.header__row1 a.header__contact-item-btn {
  background-color: #b5b5b5;
}
.header__top-menu .top-menu ul li .fa,
.header__top-menu .top-menu ul li .rt-icon,
.header__top-menu .top-menu ul li [class^="flaticon-"],
.header__top-menu .top-menu ul li [class*=" flaticon-"],
.blogdescr a > span,
.widget_recent_comments .comment-author-link,
.widget_recent_comments .comment-datetime,
.widget_recent_comments .comment-author-link a,
.widget_rss .rss-date,
ul.widget-contacts-table .rt-icon,
.recent-posts__category a,
.posts-slider__date,
.recent-projects-title,
.site__sidebar .mc4wp-form .mc4wp_button_position_absolute .fa,
.widget-width__side .mc4wp-form .mc4wp_button_position_absolute .fa,
.woocommerce div.product span.price,
.woocommerce div.product p.price,
.woocommerce div.product span.price ins,
.woocommerce div.product p.price ins,
.member-team-wrapper #cct_contact_error,
.member-contacts .rt-icon,
.front-posts-layout--2col .excerpt-more .more-link,
.front-posts-layout--2colws .excerpt-more .more-link,
.front-posts-layout--2colwsl .excerpt-more .more-link,
.before-title a,
.after-content .edit-link a,
.after-content .cat-links a,
.after-content .tags-links a,
.error404 .search-form input[type="submit"],
.chat-transcript .chat-author,
.format-quote .entry-content .post-content blockquote cite,
.format-quote .entry-content .post-content blockquote cite a,
.format-quote.has-post-thumbnail .entry-title,
.format-quote.has-post-thumbnail .entry-title a,
.format-quote.has-post-thumbnail .entry-content .post-content blockquote cite,
.format-quote.has-post-thumbnail .entry-content .post-content blockquote cite a,
.format-aside.has-post-thumbnail .entry-title,
.format-aside.has-post-thumbnail .entry-title a,
.format-status .entry-content .post-content--status,
.format-status.has-post-thumbnail .entry-title,
.format-status.has-post-thumbnail .entry-title a,
.author-info .author-link,
.comment-author,
.comment-author a,
.copyright .fa,
.copyright .rt-icon,
.header__top-menu .top-menu ul li strong {
  color: #b5b5b5;
}
@media (min-width: 1045px) {
  .is-sticky .header__row3.header-sticky-2 {
    background-color: #b5b5b5;
  }
}
.site__sidebar .widget-title::before {
  background-color: #b5b5b5;
}
.widget_archive li a::before {
  color: #b5b5b5;
}
.widget_categories li a::before {
  color: #b5b5b5;
}
.widget_nav_menu li a::before {
  color: #b5b5b5;
}
.widget_pages li a::before {
  color: #b5b5b5;
}
.widget_recent_comments li a:hover, .widget_recent_comments li a:focus {
  color: #b5b5b5;
}
.working-hours ul li::before {
  color: #b5b5b5;
}
.layout-3 .recent-posts__content,
.layout-2 .recent-posts__content {
  border-bottom-color: #b5b5b5;
}
.rp-carousel__category a:hover {
  color: #b5b5b5;
}
.rp-carousel__title a:hover, .rp-carousel__title a:focus {
  color: #b5b5b5;
}
.rp-show-description .rp-carousel__image::after {
  background-color: #b5b5b5;
}
.rp-show-description .rp-carousel__content {
  border-bottom-color: #b5b5b5;
}
.rp-show-description .rp-carousel__title a:hover, .rp-show-description .rp-carousel__title a:focus {
  color: #b5b5b5;
}
.posts-slider__title a:hover, .posts-slider__title a:active, .posts-slider__title a:focus {
  color: #b5b5b5;
}
.recent-projects-item-content .overlay::before {
  background-color: #b5b5b5;
}
.recent-projects-item-content .overlay::after {
  background-color: #b5b5b5;
}
.recent-projects-item-content:hover .recent-projects-title a,
.recent-projects-item-content:hover .recent-projects-title a:focus,
.recent-projects-item-content:hover .recent-projects-title a:active {
  color: #b5b5b5;
}
.rpj-carousel__image a::after {
  background-color: #b5b5b5;
}
.oildrop-getaquote {
  border-top-color: #b5b5b5;
}
.woocommerce div.product div.images .zoom::after {
  background-color: #b5b5b5;
}
.woocommerce div.product .woocommerce-tabs ul.tabs > li > a:hover {
  border-color: #b5b5b5;
}
.woocommerce span.onsale::before {
  border-top-color: #b5b5b5;
}
.woocommerce ul.products li.product h3::before {
  color: #b5b5b5;
}
.woocommerce ul.products li.product .product__thumbnail::after {
  background-color: #b5b5b5;
}
.woocommerce ul.products li.product .price {
  color: #b5b5b5;
}
.woocommerce a.button,
.woocommerce button.button,
.woocommerce input.button,
.woocommerce #respond input#submit {
  background-color: #b5b5b5;
}
.woocommerce a.button.alt:hover,
.woocommerce button.button.alt:hover,
.woocommerce input.button.alt:hover,
.woocommerce #respond input#submit.alt:hover {
  background-color: #b5b5b5;
}
.woocommerce ul.product_list_widget:not(.cart_list) li a .image-wrap::after {
  background-color: #b5b5b5;
}
.woocommerce-message,
.woocommerce-error,
.woocommerce-info {
  border-top-color: #b5b5b5;
}
.front-posts-layout--1col .post__inner,
.front-posts-layout--1colws .post__inner,
.front-posts-layout--1colwsl .post__inner {
  border-bottom-color: #b5b5b5;
}
@media (min-width: 568px) {
  .front-posts-layout--1col .has-oembed,
  .front-posts-layout--1colws .has-oembed,
  .front-posts-layout--1colwsl .has-oembed {
    border-bottom-color: #b5b5b5;
  }
}
.front-posts-layout--1col .entry-title a:hover,
.front-posts-layout--1colws .entry-title a:hover,
.front-posts-layout--1colwsl .entry-title a:hover {
  color: #b5b5b5;
}
.front-posts-layout--2col .post__media a.post-thumbnail,
.front-posts-layout--2colws .post__media a.post-thumbnail,
.front-posts-layout--2colwsl .post__media a.post-thumbnail {
  border-top-color: #b5b5b5;
}
.front-posts-layout--2col .entry-title a:hover,
.front-posts-layout--2colws .entry-title a:hover,
.front-posts-layout--2colwsl .entry-title a:hover {
  color: #b5b5b5;
}
.search .entry-content,
.archive .entry-content {
  border-bottom-color: #b5b5b5;
}
.single-post .entry-content__inner {
  border-bottom-color: #b5b5b5;
}
.post .featured {
  background: #b5b5b5;
}
.post-controls .pctrl-like-btn a:hover,
.post-controls .pctrl-like-btn a:focus {
  color: #b5b5b5;
}
.post-controls .share-icons a:hover,
.post-controls .share-icons a:focus {
  color: #b5b5b5;
}
.before-title .posted-on a:hover, .before-title .posted-on a:focus {
  color: #b5b5b5;
}
.to-top {
  background-color: #b5b5b5;
}
.to-top:hover {
  background-color: #b5b5b5;
}
.error404 .search-form label:after {
  color: #b5b5b5;
}
.single-format-gallery .post__media .gallery {
  border-top-color: #b5b5b5;
}
.format-quote .entry-content {
  border-bottom-color: #b5b5b5;
}
.format-link .entry-content {
  border-bottom-color: #b5b5b5;
}
.format-link.has-post-thumbnail .entry-content a:hover, .format-link.has-post-thumbnail .entry-content a:focus {
  color: #b5b5b5;
}
.format-aside .entry-content {
  border-bottom-color: #b5b5b5;
}
.format-aside .entry-content .entry-title + .posted-on a:hover, .format-aside .entry-content .entry-title + .posted-on a:focus {
  color: #b5b5b5;
}
.format-status .entry-content {
  border-bottom-color: #b5b5b5;
}
.format-status .entry-content .post-content--status a:hover, .format-status .entry-content .post-content--status a:focus,
.format-status .entry-content .post-content--status + .posted-on a:hover,
.format-status .entry-content .post-content--status + .posted-on a:focus {
  color: #b5b5b5;
}
.comment-metadata a:hover, .comment-metadata a:focus,
.pingback .edit-link a:hover,
.pingback .edit-link a:focus {
  color: #b5b5b5;
}
.comment-list .reply a:hover, .comment-list .reply a:focus {
  color: #b5b5b5;
}
@media (min-width: 768px) {
  .comment-list .reply a:hover .fa, .comment-list .reply a:focus .fa {
    background-color: #b5b5b5;
  }
}
.comment-reply-title small a:hover,
.comment-reply-title small a:hover::after {
  color: #b5b5b5;
}
.comment-navigation .current,
.comment-navigation a:hover,
.comment-navigation a:focus {
  background-color: #b5b5b5;
}
.copyright a:hover, .copyright a:focus {
  color: #b5b5b5;
}
.owl-carousel .owl-nav .owl-prev:hover, .owl-carousel .owl-nav .owl-prev:focus,
.owl-carousel .owl-nav .owl-next:hover,
.owl-carousel .owl-nav .owl-next:focus {
  background-color: #b5b5b5;
}
.owl-carousel .owl-dot:hover {
  border-color: #b5b5b5;
}
.owl-carousel .owl-dot:hover span {
  background-color: #b5b5b5;
}

.portfolio-categories--single li a,
.portfolio__zoom,
.portfolio__info,
.fw-btn {
  background-color: #b5b5b5;
}
.fw-btn__black:hover, .fw-btn__black:focus {
  background-color: #b5b5b5 !important;
}
.fw-action__inner {
  border-color: #b5b5b5;
}
.fw-iconbox--top .fw-iconbox__image i,
.section-dark-bg .fw-iconbox--left .fw-iconbox__title h3,
.section-dark-bg .fw-iconbox--left .fw-iconbox__text span,
.section-dark-bg .fw-iconbox--left .fw-iconbox__text strong,
.fw-special__title span span,
.fw-special__subtitle,
.fw-package .fw-pricing-row span,
.fw-pricing .fw-package-wrap.highlight-col .fw-heading-row span,
.fw-team:hover .fw-team__name,
.fw-team:hover .fw-team__name a,
.fw-testimonials__job,
.fw-listbox-title,
.wrap-twitter ul li span,
.wrap-twitter ul li span .fa,
.fw-icon i {
  color: #b5b5b5;
}
.fw-iconbox--top .fw-iconbox__title h3::before {
  background-color: #b5b5b5;
}
.fw-heading--alternate::before {
  background-color: #b5b5b5;
}
.fw-pricing .fw-package-wrap.highlight-col .fw-package {
  border-bottom-color: #b5b5b5;
}
.fw-tabs .nav-tabs > li > a:hover {
  border-color: #b5b5b5;
}
.fw-team:hover {
  border-bottom-color: #b5b5b5;
}
.fw-team__text::before {
  background-color: #b5b5b5;
}
.fw-testimonials__meta::before {
  background-color: #b5b5b5;
}
.fw-testimonials__url a:hover, .fw-testimonials__url a:active {
  color: #b5b5b5;
}
.fw-skills-bar .progress-bar {
  background-color: #b5b5b5;
  background: -webkit-linear-gradient(left, #ea822d 0%, #b5b5b5 100%);
  background: linear-gradient(to right, #ea822d 0%, #b5b5b5 100%);
}
.fw-listbox {
  border-bottom-color: #b5b5b5;
}
.unyson-media-image a::after {
  background-color: #b5b5b5;
}
.wrap-blog-tabs .nav-tabs > li > a:hover, .wrap-blog-tabs .nav-tabs > li > a:focus {
  background-color: #b5b5b5;
}
.single-fw-portfolio .entry-content__inner {
  border-bottom-color: #b5b5b5;
}
.portfolio--alternate .portfolio__title a:hover, .portfolio--alternate .portfolio__title a:focus,
.portfolio--extended .portfolio__title a:hover,
.portfolio--extended .portfolio__title a:focus {
  color: #b5b5b5;
}
.fw-iconbox--left .fw-iconbox__title h3 a:hover,
.fw-iconbox--left .fw-iconbox__title h3 a:focus,
.fw-iconbox--top .fw-iconbox__title h3 a:hover,
.fw-iconbox--top .fw-iconbox__title h3 a:focus
{
  color: #b5b5b5;
}
.format-link .the-content a:hover,
.format-link .the-content a:focus,
.logged-in-as a:hover,
.logged-in-as a:focus,
.woocommerce ul.cart_list li a:hover, .woocommerce ul.product_list_widget li a:hover,
.woocommerce ul.cart_list li a:focus, .woocommerce ul.product_list_widget li a:focus,
a:hover .star-rating span,
a:focus .star-rating span,
.cat-item a:hover,
.cat-item a:focus,
.woocommerce-review-link:hover,
.woocommerce-review-link:focus,
.product_meta .posted_in a:hover,
.product_meta .posted_in a:focus,
.content-more-link
{
  color: #b5b5b5;
}
.header__row1 .top-menu a:hover strong,
.header__row1 .top-menu a:active strong,
.header__row1 .top-menu a:focus strong {
	color: #b5b5b5;
}

.recent-posts__media:hover .overlay
{
  color: rgba( 14, 176, 238, 0.85);
}

/** 
 * Accent Color 2
 * --------------
 */
 
.header__row2,
.footer,

.btn.active,
.btn:active,
.button:hover,
.button:focus,
.button:focus,
button:hover,
button:focus,
input[type="button"]:hover,
input[type="button"]:focus,
input[type="reset"]:hover,
input[type="reset"]:focus,
input[type="submit"]:hover,
input[type="submit"]:focus,

.fw-listbox,
.fw-iconbox--top .fw-iconbox__image::before,
.fw-testimonials .owl-carousel .owl-dot.active span,
a.header__contact-item-btn:hover, a.header__contact-item-btn:focus,
.fw-btn:hover, .fw-btn:focus,
.header__row1 a.header__contact-item-btn:hover, .header__row1 a.header__contact-item-btn:focus,
.fw-accordion__title a,
.fw-pricing .fw-package-wrap.highlight-col .fw-package,
.fw-team:hover,
.fw-tabs .nav-tabs > li.active > a, .fw-tabs .nav-tabs > li.active > a:hover, .fw-tabs .nav-tabs > li.active > a:focus,
.homepage_link a:hover, .homepage_link a:focus,
.sidebar-before-content .recent-posts.layout-3,
.sidebar-before-content .recent-posts.layout-3::before, .sidebar-before-content .recent-posts.layout-3::after,
.widget_product_tag_cloud .tagcloud a:hover,
.widget_product_tag_cloud .tagcloud a:focus,
.widget_tag_cloud .tagcloud a:hover,
.widget_tag_cloud .tagcloud a:focus,
.post-controls .pctrl-social-btn,
.post-controls .pctrl-view,
.author-info,
.post-navigation .nav-next a, .post-navigation .nav-previous a,
.portfolio-categories li a:hover, .portfolio-categories li a:focus,
.woocommerce ul.products li.product .product__thumbnail::before,
.woocommerce a.button:hover,
.woocommerce button.button:hover,
.woocommerce input.button:hover,
.woocommerce #respond input#submit:hover,
.woocommerce .widget_price_filter .price_slider_wrapper .ui-widget-content,
.woocommerce a.button.alt,
.woocommerce button.button.alt,
.woocommerce input.button.alt,
.woocommerce #respond input#submit.alt,
.woocommerce div.product .woocommerce-tabs ul.tabs > li.active > a, 
.woocommerce div.product .woocommerce-tabs ul.tabs > li.active > a:hover, 
.woocommerce div.product .woocommerce-tabs ul.tabs > li.active > a:focus,
.woocommerce ul.product_list_widget:not(.cart_list) li a .image-wrap::before
{
	background-color: #ea822d;
}

.main-nav > ul > li.marked a:hover, .main-nav > ul > li.marked a:focus,
.section-dark-bg .fw-btn:hover, .section-dark-bg .fw-btn:focus,
.mc4wp-form-fields input[type="submit"]:hover,
.fw-pricing .fw-package-wrap.highlight-col .fw-btn:hover,
.breadcrumbs span.last-item, .breadcrumbs span a:hover, .breadcrumbs span a:focus,
.before-title a:hover, .before-title a:focus,
.recent-posts__category a:hover, .recent-posts__category a:focus,
.widget_search .search-form label::before,
.widget_categories li a:hover, .widget_categories li a:focus,
.widget_recent_comments .comment-author-link a:hover,
ul.share-icons > li > a,
a.like_button,
.widget_social_links ul li a:hover,
.after-content .edit-link a:hover,
.after-content .edit-link a:hover,
.after-content .cat-links a:hover,
.after-content .cat-links a:hover,
.after-content .tags-links a:hover,
.after-content .tags-links a:hover,
.logged-in-as a,
.comment-list .reply a .fa,
.portfolio-categories li a,
.portfolio__zoom:hover, .portfolio__zoom:focus, .portfolio__info:hover, .portfolio__info:focus,
.portfolio-categories--single li a:hover, .portfolio-categories--single li a:focus,
.star-rating span,
.woocommerce ul.products li.product .price ins,
.cat-item a,
.woocommerce nav.woocommerce-pagination ul li a,
.woocommerce-review-link,
.widget_product_search .woocommerce-product-search::before,
.product_meta .posted_in a,
.woocommerce form .form-row label,
.content-more-link:hover,
.content-more-link:focus
{
	color: #ea822d;
}
 
.fw-testimonials .owl-carousel .owl-dot.active,
.fw-tabs .nav-tabs
{
	border-color: #ea822d;
}
 
.fw-testimonials .owl-carousel .owl-dot::before,
.woocommerce div.product .woocommerce-tabs ul.tabs
{
	border-bottom-color: #ea822d;
}

.is-sticky .header__row2,
.footer::after,
.posts-slider__overlay
{
	background-color: rgba(234, 130, 45, 1);
}

.posts-slider:hover .posts-slider__overlay
{
	background-color: rgba( 48, 53, 93, 0.8);
}

a.post-thumbnail:hover::before, a.post-thumbnail:focus::before
{
	background-color: rgba( 48, 53, 93, 0.5);
}

.format-status.has-post-thumbnail .entry-content::after,
.format-quote.has-post-thumbnail .entry-content::after,
.portfolio__hover
{
	background-color: rgba( 48, 53, 93, 0.9);
}


/** 
 * Accent Color 3
 * --------------
 */

.header__row3,
.header__row3 a,
.header__row3 .header__contact-item-text,
.header__row3 .header__contact-item-text a,
.header__row3 .header__contact-item-text a:hover,
.header__row3 .header__contact-item-text a:active,
.header__row3 .header__contact-item-text a:focus
{
	color: #8ae3ff;
}

.header__contact-item .fa
{
	border-color: #ea822d;
}


</style>
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jquery.js'></script>
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jquery-migrate.min.js'></script>
<link rel='https://api.w.org/' href='http://webdesign-finder.com/oildrop/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://webdesign-finder.com/oildrop/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://webdesign-finder.com/oildrop/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.9.14" />
<meta name="generator" content="WooCommerce 3.5.2" />
<link rel="canonical" href="http://webdesign-finder.com/oildrop/" />
<link rel='shortlink' href='http://webdesign-finder.com/oildrop/' />
<link rel="alternate" type="application/json+oembed" href="http://webdesign-finder.com/oildrop/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fwebdesign-finder.com%2Foildrop%2F" />
<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="alternate" type="text/xml+oembed" href="http://webdesign-finder.com/oildrop/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fwebdesign-finder.com%2Foildrop%2F&#038;format=xml" />
<script type="text/javascript"> if( ajaxurl === undefined ) var ajaxurl = "http://webdesign-finder.com/oildrop/wp-admin/admin-ajax.php";</script>	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
			<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
		<meta name="generator" content="Powered by Slider Revolution 5.4.8 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<script type="text/javascript">function setREVStartSize(e){									
						try{ e.c=jQuery(e.c);var i=jQuery(window).width(),t=9999,r=0,n=0,l=0,f=0,s=0,h=0;
							if(e.responsiveLevels&&(jQuery.each(e.responsiveLevels,function(e,f){f>i&&(t=r=f,l=e),i>f&&f>r&&(r=f,n=e)}),t>r&&(l=n)),f=e.gridheight[l]||e.gridheight[0]||e.gridheight,s=e.gridwidth[l]||e.gridwidth[0]||e.gridwidth,h=i/s,h=h>1?1:h,f=Math.round(h*f),"fullscreen"==e.sliderLayout){var u=(e.c.width(),jQuery(window).height());if(void 0!=e.fullScreenOffsetContainer){var c=e.fullScreenOffsetContainer.split(",");if (c) jQuery.each(c,function(e,i){u=jQuery(i).length>0?u-jQuery(i).outerHeight(!0):u}),e.fullScreenOffset.split("%").length>1&&void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0?u-=jQuery(window).height()*parseInt(e.fullScreenOffset,0)/100:void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0&&(u-=parseInt(e.fullScreenOffset,0))}f=u}else void 0!=e.minHeight&&f<e.minHeight&&(f=e.minHeight);e.c.closest(".rev_slider_wrapper").css({height:f})					
						}catch(d){console.log("Failure at Presize of Slider:"+d)}						
					};</script>
</head>
<body class="home page-template-default page page-id-6 woocommerce-no-js hide_header_search__true oildrop blog_post_visibility__excerpt post_id_6">


<div class="body-overlay"></div>

<div class="sidebar-before-header widget-width__full"><div class="row mod-widget-grid"></div></div><!-- .sidebar-before-header -->        <div class="header-wrapper header-wrapper-before" id="header-wrapper">
        <div class="header header__style3  header-logo-image has-header-row1">

        <div class="header__row3 header-sticky-2">
            <div class="container">
                <div class="row">

	                
                    <!-- Header Logo -->
                    <div class="header__logo col-md-3 col-sm-12 col-xs-12">
                        <div class="header__logo-inner">
                            <div class="logo-div logo logo-use-image">
								                                    <a href="http://webdesign-finder.com/oildrop/">
                                        <img alt="Logo" class="logo logo_big"
                                             src="<?php echo base_url(); ?>assets/images/uniflex.png"/>
                                    </a>
								                            </div><!-- .logo-->
                        </div><!-- .header__logo-inner -->
                    </div><!-- .header__logo -->

					
                        <div class="header__contact col-lg-3 col-md-4 col-sm-6 col-xs-6">
                            <div class="header__contact-inner">
								<span class="header__contact-item">
                                    <span class="header__contact-item-icon">
                                        <i class="fa fa-map-marker" style="border: none;"></i>
                                    </span>
                                    <span class="header__contact-item-text">
                                        <span><a href="javascript:void(0)" style="color: #fff;"><span>15 Falcon Lane, Douglasdale</span><span  style="color: #fff;">Sandton, 2191, Johannesburg</span></a></span>
                                    </span>
								</span>
                            </div>
                        </div><!-- .header__contact -->

                        <div class="header__contact col-lg-3 col-md-4 col-sm-6 col-xs-6">
                            <div class="header__contact-inner">
								<span class="header__contact-item">
                                    <span class="header__contact-item-icon">
                                        <i class="fa fa-map-marker" style="border: none;"></i>
                                    </span>
                                    <span class="header__contact-item-text">
                                        <span><a href="javascript:void(0)" style="color: #fff;"><span>06 TRAILL ROAD, MOUNT PLEASANT
, Harare, Zimbabwe</span></a></span>
                                    </span>
								</span>
                            </div>
                        </div><!-- .header__contact -->

                        <div class="header__contact col-lg-3 col-md-1 col-sm-6 col-xs-6 header__contact_call_back">
                            <div class="header__contact-inner">
								<span class="header__contact-item">
                                    <span class="header__contact-item-text">
									    <a href="<?php echo site_url(); ?>Contact" class="header__contact-item-btn">
                                            <i class="fa fa-phone"></i>
                                            <span class="header__contact-item-btn-text">Request Quote</span>
                                        </a>
                                    </span>
								</span>
                            </div>
                        </div><!-- .header__contact -->

					
                </div><!-- .row -->
            </div><!-- .container -->
        </div><!-- .header__row3 -->


        </div><!-- .header__style3 -->
        </div><!-- .header-wrapper -->

		<link href="https://fonts.googleapis.com/css?family=Open+Sans:400%7CKanit:700%7CRoboto:700" rel="stylesheet" property="stylesheet" type="text/css" media="all">
<div id="rev_slider_1_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container" data-source="gallery" style="margin:0px auto;background:#b5b5b5;padding:0px;margin-top:0px;margin-bottom:0px;">
<!-- START REVOLUTION SLIDER 5.4.8 auto mode -->
	<div id="rev_slider_1_1" class="rev_slider fullwidthabanner tp-overflow-hidden" style="display:none;" data-version="5.4.8">
<ul>	<!-- SLIDE  -->
	<li data-index="rs-1" data-transition="slidingoverlayvertical" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="default"  data-thumb="http://webdesign-finder.com/oildrop/wp-content/uploads/2017/01/oildrop_slider__bg-100x50.jpg"  data-rotate="0"  data-fstransition="fade" data-fsmasterspeed="300" data-fsslotamount="7" data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
		<!-- MAIN IMAGE -->
		<img src=""  alt="" title="oildrop_slider__bg"  width="1920" height="862" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina>
		<!-- LAYERS -->

		<!-- LAYER NR. 1 -->
		<div class="tp-caption   tp-resizeme rs-parallaxlevel-4" 
			 id="slide-1-layer-5" 
			 data-x="['center','center','center','center']" data-hoffset="['10','10','10','10']" 
			 data-y="['bottom','bottom','bottom','bottom']" data-voffset="['-70','-70','-70','-70']" 
						data-width="none"
			data-height="none"
			data-whitespace="nowrap"
 
			data-type="image" 
			data-basealign="slide" 
			data-responsive_offset="on" 

			data-frames='[{"delay":0,"speed":1500,"frame":"0","from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","to":"o:1;","ease":"Power4.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'
			data-textAlign="['inherit','inherit','inherit','inherit']"
			data-paddingtop="[0,0,0,0]"
			data-paddingright="[0,0,0,0]"
			data-paddingbottom="[0,0,0,0]"
			data-paddingleft="[0,0,0,0]"

			style="z-index: 5;"><img src="<?php echo base_url(); ?>assets/images/slider/1.png" alt="" data-ww="['1920px','1920px','1920px','1920px']" data-hh="['862px','862px','862px','862px']" width="1920" height="862" data-no-retina> </div>

		<!-- LAYER NR. 2 -->
		<div class="tp-caption   tp-resizeme rs-parallaxlevel-7" 
			 id="slide-1-layer-6" 
			 data-x="['center','center','center','center']" data-hoffset="['-140','-140','-140','-140']" 
			 data-y="['bottom','bottom','bottom','bottom']" data-voffset="['-50','-50','-50','-50']" 
						data-width="none"
			data-height="none"
			data-whitespace="nowrap"
 
			data-type="image" 
			data-responsive_offset="on" 

			data-frames='[{"delay":250,"speed":1500,"frame":"0","from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","to":"o:1;","ease":"Power4.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'
			data-textAlign="['inherit','inherit','inherit','inherit']"
			data-paddingtop="[0,0,0,0]"
			data-paddingright="[0,0,0,0]"
			data-paddingbottom="[0,0,0,0]"
			data-paddingleft="[0,0,0,0]"

			style="z-index: 6;"><img src="<?php echo base_url(); ?>images/assets/slider/1.png" alt="" data-ww="['1920px','1920px','1920px','1920px']" data-hh="['862px','862px','862px','862px']" width="1920" height="862" data-no-retina> </div>

		<!-- LAYER NR. 3 -->
		<div class="tp-caption   tp-resizeme" 
			 id="slide-1-layer-7" 
			 data-x="['right','right','right','right']" data-hoffset="['-60','-290','-320','-140']" 
			 data-y="['bottom','bottom','bottom','bottom']" data-voffset="['0','0','0','0']" 
						data-width="none"
			data-height="none"
			data-whitespace="nowrap"
			data-visibility="['on','on','on','off']"
 
			data-type="image" 
			data-basealign="slide" 
			data-responsive_offset="on" 

			data-frames='[{"delay":500,"speed":1000,"frame":"0","from":"x:50px;opacity:0;","to":"o:1;","ease":"Power3.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'
			data-textAlign="['inherit','inherit','inherit','inherit']"
			data-paddingtop="[0,0,0,0]"
			data-paddingright="[0,0,0,0]"
			data-paddingbottom="[0,0,0,0]"
			data-paddingleft="[0,0,0,0]"

			style="z-index: 7;"><img src="<?php echo base_url(); ?>assets/images/slider/1.png" alt="" data-ww="['1920px','1920px','1920px','1920px']" data-hh="['862px','862px','862px','862px']" width="1920" height="862" data-no-retina> </div>

		<!-- LAYER NR. 4 -->
		<div class="tp-caption oildrop_category   tp-resizeme" 
			 id="slide-1-layer-1" 
			 data-x="['left','left','left','left']" data-hoffset="['65','15','15','16']" 
			 data-y="['top','top','top','top']" data-voffset="['270','180','160','60']" 
						data-width="none"
			data-height="23"
			data-whitespace="nowrap"
 
			data-type="text" 
			data-responsive_offset="on" 

			data-frames='[{"delay":0,"speed":1500,"frame":"0","from":"y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'
			data-textAlign="['inherit','inherit','inherit','inherit']"
			data-paddingtop="[0,0,0,0]"
			data-paddingright="[0,0,0,0]"
			data-paddingbottom="[0,0,0,0]"
			data-paddingleft="[0,0,0,0]"

			style="z-index: 8; max-width: 23px; max-width: 23px; white-space: nowrap; letter-spacing: px;"></div>

		<!-- LAYER NR. 5 -->
		<div class="tp-caption oildrop_title   tp-resizeme" 
			 id="slide-1-layer-2" 
			 data-x="['left','left','left','left']" data-hoffset="['65','15','15','16']" 
			 data-y="['top','top','top','top']" data-voffset="['310','220','200','100']" 
						data-fontsize="['88','88','88','30']"
			data-lineheight="['83','83','83','35']"
			data-width="['800','800','800','300']"
			data-height="none"
			data-whitespace="normal"
 
			data-type="text" 
			data-responsive_offset="on" 

			data-frames='[{"delay":250,"speed":1500,"frame":"0","from":"y:bottom;rX:-20deg;rY:-20deg;rZ:0deg;","to":"o:1;","ease":"Power3.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'
			data-textAlign="['inherit','inherit','inherit','inherit']"
			data-paddingtop="[0,0,0,0]"
			data-paddingright="[0,0,0,0]"
			data-paddingbottom="[0,0,0,0]"
			data-paddingleft="[0,0,0,0]"

			style="z-index: 9; min-width: 800px; max-width: 800px; white-space: normal; letter-spacing: px;letter-spacing:-2px;">MINE VENTILATION SYSTEMS</div>

		<!-- LAYER NR. 6 -->
		<div class="tp-caption oildrop_text   tp-resizeme" 
			 id="slide-1-layer-3" 
			 data-x="['left','left','left','left']" data-hoffset="['65','15','15','16']" 
			 data-y="['top','top','top','top']" data-voffset="['510','420','400','200']" 
						data-width="['none','none','none','301']"
			data-height="['23','23','23','none']"
			data-whitespace="['nowrap','nowrap','nowrap','normal']"
 
			data-type="text" 
			data-responsive_offset="on" 

			data-frames='[{"delay":500,"speed":1500,"frame":"0","from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","mask":"x:0px;y:[100%];s:inherit;e:inherit;","to":"o:1;","ease":"Power2.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'
			data-textAlign="['inherit','inherit','inherit','inherit']"
			data-paddingtop="[0,0,0,0]"
			data-paddingright="[0,0,0,0]"
			data-paddingbottom="[0,0,0,0]"
			data-paddingleft="[0,0,0,0]"

			style="z-index: 10; max-width: 23px; max-width: 23px; white-space: nowrap; letter-spacing: px;"></div>
	</li>
	<!-- SLIDE  -->
	<li data-index="rs-4" data-transition="slidingoverlayvertical" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="default"  data-thumb="http://webdesign-finder.com/oildrop/wp-content/uploads/2017/01/oildrop_slider__bg-100x50.jpg"  data-rotate="0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
		<!-- MAIN IMAGE -->
		<!-- <img src="http://webdesign-finder.com/oildrop/wp-content/uploads/2017/01/oildrop_slider__bg.jpg"  alt="" title="oildrop_slider__bg"  width="1920" height="862" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina> -->
		<!-- LAYERS -->

		<!-- LAYER NR. 7 -->
		<div class="tp-caption   tp-resizeme rs-parallaxlevel-4" 
			 id="slide-4-layer-5" 
			 data-x="['center','center','center','center']" data-hoffset="['10','10','10','10']" 
			 data-y="['bottom','bottom','bottom','bottom']" data-voffset="['-70','-70','-70','-70']" 
						data-width="none"
			data-height="none"
			data-whitespace="nowrap"
 
			data-type="image" 
			data-basealign="slide" 
			data-responsive_offset="on" 

			data-frames='[{"delay":0,"speed":1500,"frame":"0","from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","to":"o:1;","ease":"Power4.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'
			data-textAlign="['inherit','inherit','inherit','inherit']"
			data-paddingtop="[0,0,0,0]"
			data-paddingright="[0,0,0,0]"
			data-paddingbottom="[0,0,0,0]"
			data-paddingleft="[0,0,0,0]"

			style="z-index: 5;"><img src="<?php echo base_url(); ?>assets/images/slider/1.png" alt="" data-ww="['1920px','1920px','1920px','1920px']" data-hh="['862px','862px','862px','862px']" width="1920" height="862" data-no-retina> </div>

		<!-- LAYER NR. 8 -->
		<div class="tp-caption   tp-resizeme rs-parallaxlevel-7" 
			 id="slide-4-layer-6" 
			 data-x="['center','center','center','center']" data-hoffset="['-140','-140','-140','-140']" 
			 data-y="['bottom','bottom','bottom','bottom']" data-voffset="['-50','-50','-50','-50']" 
						data-width="none"
			data-height="none"
			data-whitespace="nowrap"
 
			data-type="image" 
			data-responsive_offset="on" 

			data-frames='[{"delay":250,"speed":1500,"frame":"0","from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","to":"o:1;","ease":"Power4.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'
			data-textAlign="['inherit','inherit','inherit','inherit']"
			data-paddingtop="[0,0,0,0]"
			data-paddingright="[0,0,0,0]"
			data-paddingbottom="[0,0,0,0]"
			data-paddingleft="[0,0,0,0]"

			style="z-index: 6;"><img src="<?php echo base_url(); ?>assets/images/slider/1.png" alt="" data-ww="['1920px','1920px','1920px','1920px']" data-hh="['862px','862px','862px','862px']" width="1920" height="862" data-no-retina> </div>

		<!-- LAYER NR. 9 -->
		<div class="tp-caption oildrop_category   tp-resizeme" 
			 id="slide-4-layer-1" 
			 data-x="['left','left','left','left']" data-hoffset="['65','15','15','15']" 
			 data-y="['top','top','top','top']" data-voffset="['270','110','90','60']" 
						data-width="none"
			data-height="23"
			data-whitespace="nowrap"
 
			data-type="text" 
			data-responsive_offset="on" 

			data-frames='[{"delay":0,"speed":1500,"frame":"0","from":"y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'
			data-textAlign="['inherit','inherit','inherit','inherit']"
			data-paddingtop="[0,0,0,0]"
			data-paddingright="[0,0,0,0]"
			data-paddingbottom="[0,0,0,0]"
			data-paddingleft="[0,0,0,0]"

			style="z-index: 7; max-width: 23px; max-width: 23px; white-space: nowrap; letter-spacing: px;"> </div>

		<!-- LAYER NR. 10 -->
		<div class="tp-caption oildrop_title   tp-resizeme" 
			 id="slide-4-layer-2" 
			 data-x="['left','left','left','left']" data-hoffset="['65','15','15','15']" 
			 data-y="['top','top','top','top']" data-voffset="['310','150','130','100']" 
						data-fontsize="['88','88','88','30']"
			data-lineheight="['83','83','83','35']"
			data-width="['990','800','740','300']"
			data-height="none"
			data-whitespace="normal"
 
			data-type="text" 
			data-responsive_offset="on" 

			data-frames='[{"delay":250,"speed":1500,"frame":"0","from":"y:bottom;rX:-20deg;rY:-20deg;rZ:0deg;","to":"o:1;","ease":"Power3.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'
			data-textAlign="['inherit','inherit','inherit','inherit']"
			data-paddingtop="[0,0,0,0]"
			data-paddingright="[0,0,0,0]"
			data-paddingbottom="[0,0,0,0]"
			data-paddingleft="[0,0,0,0]"

			style="z-index: 8; min-width: 990px; max-width: 990px; white-space: normal; letter-spacing: px;letter-spacing:-2px;">MINE VENTILATION SYSTEMS</div>

		<!-- LAYER NR. 11 -->
		<div class="tp-caption oildrop_text   tp-resizeme" 
			 id="slide-4-layer-3" 
			 data-x="['left','left','left','left']" data-hoffset="['65','15','15','15']" 
			 data-y="['top','top','top','top']" data-voffset="['510','420','400','200']" 
						data-width="['none','none','none','301']"
			data-height="['23','23','23','none']"
			data-whitespace="['nowrap','nowrap','nowrap','normal']"
 
			data-type="text" 
			data-responsive_offset="on" 

			data-frames='[{"delay":500,"speed":1500,"frame":"0","from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","mask":"x:0px;y:[100%];s:inherit;e:inherit;","to":"o:1;","ease":"Power2.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'
			data-textAlign="['inherit','inherit','inherit','inherit']"
			data-paddingtop="[0,0,0,0]"
			data-paddingright="[0,0,0,0]"
			data-paddingbottom="[0,0,0,0]"
			data-paddingleft="[0,0,0,0]"

			style="z-index: 9; max-width: 23px; max-width: 23px; white-space: nowrap; letter-spacing: px;"></div>
	</li>
	<!-- SLIDE  -->
	<li data-index="rs-5" data-transition="slidingoverlayvertical" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="default"  data-thumb="http://webdesign-finder.com/oildrop/wp-content/uploads/2017/01/oildrop_slider__bg-100x50.jpg"  data-rotate="0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
		<!-- MAIN IMAGE -->
		<img src="http://webdesign-finder.com/oildrop/wp-content/uploads/2017/01/oildrop_slider__bg.jpg"  alt="" title="oildrop_slider__bg"  width="1920" height="862" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina>
		<!-- LAYERS -->

		<!-- LAYER NR. 12 -->
		<div class="tp-caption   tp-resizeme rs-parallaxlevel-4" 
			 id="slide-5-layer-5" 
			 data-x="['center','center','center','center']" data-hoffset="['10','10','10','10']" 
			 data-y="['bottom','bottom','bottom','bottom']" data-voffset="['-70','-70','-70','-70']" 
						data-width="none"
			data-height="none"
			data-whitespace="nowrap"
 
			data-type="image" 
			data-basealign="slide" 
			data-responsive_offset="on" 

			data-frames='[{"delay":0,"speed":1500,"frame":"0","from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","to":"o:1;","ease":"Power4.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'
			data-textAlign="['inherit','inherit','inherit','inherit']"
			data-paddingtop="[0,0,0,0]"
			data-paddingright="[0,0,0,0]"
			data-paddingbottom="[0,0,0,0]"
			data-paddingleft="[0,0,0,0]"

			style="z-index: 5;"><img src="<?php echo base_url(); ?>assets/images/slider/1.png" alt="" data-ww="['1920px','1920px','1920px','1920px']" data-hh="['862px','862px','862px','862px']" width="1920" height="862" data-no-retina> </div>

		<!-- LAYER NR. 13 -->
		<div class="tp-caption   tp-resizeme rs-parallaxlevel-7" 
			 id="slide-5-layer-6" 
			 data-x="['center','center','center','center']" data-hoffset="['-140','-140','-140','-140']" 
			 data-y="['bottom','bottom','bottom','bottom']" data-voffset="['-50','-50','-50','-50']" 
						data-width="none"
			data-height="none"
			data-whitespace="nowrap"
 
			data-type="image" 
			data-responsive_offset="on" 

			data-frames='[{"delay":250,"speed":1500,"frame":"0","from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","to":"o:1;","ease":"Power4.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'
			data-textAlign="['inherit','inherit','inherit','inherit']"
			data-paddingtop="[0,0,0,0]"
			data-paddingright="[0,0,0,0]"
			data-paddingbottom="[0,0,0,0]"
			data-paddingleft="[0,0,0,0]"

			style="z-index: 6;"><img src="<?php echo base_url(); ?>images/assets/slider/1.png" alt="" data-ww="['1920px','1920px','1920px','1920px']" data-hh="['862px','862px','862px','862px']" width="1920" height="862" data-no-retina> </div>

		<!-- LAYER NR. 14 -->
		<div class="tp-caption oildrop_category   tp-resizeme" 
			 id="slide-5-layer-1" 
			 data-x="['left','left','left','left']" data-hoffset="['65','15','15','15']" 
			 data-y="['top','top','top','top']" data-voffset="['270','180','160','61']" 
						data-width="none"
			data-height="23"
			data-whitespace="nowrap"
 
			data-type="text" 
			data-responsive_offset="on" 

			data-frames='[{"delay":0,"speed":1500,"frame":"0","from":"y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'
			data-textAlign="['inherit','inherit','inherit','inherit']"
			data-paddingtop="[0,0,0,0]"
			data-paddingright="[0,0,0,0]"
			data-paddingbottom="[0,0,0,0]"
			data-paddingleft="[0,0,0,0]"

			style="z-index: 7; max-width: 23px; max-width: 23px; white-space: nowrap; letter-spacing: px;"></div>

		<!-- LAYER NR. 15 -->
		<div class="tp-caption oildrop_title   tp-resizeme" 
			 id="slide-5-layer-2" 
			 data-x="['left','left','left','left']" data-hoffset="['65','15','15','15']" 
			 data-y="['top','top','top','top']" data-voffset="['310','220','200','101']" 
						data-fontsize="['88','88','88','30']"
			data-lineheight="['83','83','83','35']"
			data-width="['800','800','800','300']"
			data-height="none"
			data-whitespace="normal"
 
			data-type="text" 
			data-responsive_offset="on" 

			data-frames='[{"delay":250,"speed":1500,"frame":"0","from":"y:bottom;rX:-20deg;rY:-20deg;rZ:0deg;","to":"o:1;","ease":"Power3.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'
			data-textAlign="['inherit','inherit','inherit','inherit']"
			data-paddingtop="[0,0,0,0]"
			data-paddingright="[0,0,0,0]"
			data-paddingbottom="[0,0,0,0]"
			data-paddingleft="[0,0,0,0]"

			style="z-index: 8; min-width: 800px; max-width: 800px; white-space: normal; letter-spacing: px;letter-spacing:-2px;">MINE VENTILATION SYSTEMS</div>

		<!-- LAYER NR. 16 -->
		<div class="tp-caption oildrop_text   tp-resizeme" 
			 id="slide-5-layer-3" 
			 data-x="['left','left','left','left']" data-hoffset="['65','15','15','15']" 
			 data-y="['top','top','top','top']" data-voffset="['510','420','400','201']" 
						data-width="['none','none','none','301']"
			data-height="['23','23','23','none']"
			data-whitespace="['nowrap','nowrap','nowrap','normal']"
 
			data-type="text" 
			data-responsive_offset="on" 

			data-frames='[{"delay":500,"speed":1500,"frame":"0","from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","mask":"x:0px;y:[100%];s:inherit;e:inherit;","to":"o:1;","ease":"Power2.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'
			data-textAlign="['inherit','inherit','inherit','inherit']"
			data-paddingtop="[0,0,0,0]"
			data-paddingright="[0,0,0,0]"
			data-paddingbottom="[0,0,0,0]"
			data-paddingleft="[0,0,0,0]"

			style="z-index: 9; max-width: 23px; max-width: 23px; white-space: nowrap; letter-spacing: px;"></div>
	</li>
</ul>
<script>var htmlDiv = document.getElementById("rs-plugin-settings-inline-css"); var htmlDivCss="";
						if(htmlDiv) {
							htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
						}else{
							var htmlDiv = document.createElement("div");
							htmlDiv.innerHTML = "<style>" + htmlDivCss + "</style>";
							document.getElementsByTagName("head")[0].appendChild(htmlDiv.childNodes[0]);
						}
					</script>
<div class="tp-bannertimer tp-bottom" style="height: 5px; background: rgba(255,255,255,0.30);"></div>	</div>
<script>
					var htmlDivCss = unescape(".custom.tparrows%20%7B%0A%09cursor%3Apointer%3B%0A%09background%3A%23000%3B%0A%09background%3Argba%280%2C0%2C0%2C0.5%29%3B%0A%09width%3A40px%3B%0A%09height%3A40px%3B%0A%09position%3Aabsolute%3B%0A%09display%3Ablock%3B%0A%09z-index%3A100%3B%0A%7D%0A.custom.tparrows%3Ahover%20%7B%0A%09background%3A%23000%3B%0A%7D%0A.custom.tparrows%3Abefore%20%7B%0A%09font-family%3A%20%22revicons%22%3B%0A%09font-size%3A15px%3B%0A%09color%3A%23fff%3B%0A%09display%3Ablock%3B%0A%09line-height%3A%2040px%3B%0A%09text-align%3A%20center%3B%0A%7D%0A.custom.tparrows.tp-leftarrow%3Abefore%20%7B%0A%09content%3A%20%22%5Ce824%22%3B%0A%7D%0A.custom.tparrows.tp-rightarrow%3Abefore%20%7B%0A%09content%3A%20%22%5Ce825%22%3B%0A%7D%0A%0A%0A.custom.tp-bullets%20%7B%0A%7D%0A.custom.tp-bullets%3Abefore%20%7B%0A%09content%3A%22%20%22%3B%0A%09position%3Aabsolute%3B%0A%09width%3A100%25%3B%0A%09height%3A100%25%3B%0A%09background%3Atransparent%3B%0A%09padding%3A10px%3B%0A%09margin-left%3A-10px%3Bmargin-top%3A-10px%3B%0A%09box-sizing%3Acontent-box%3B%0A%7D%0A.custom%20.tp-bullet%20%7B%0A%09width%3A12px%3B%0A%09height%3A12px%3B%0A%09position%3Aabsolute%3B%0A%09background%3A%23aaa%3B%0A%20%20%20%20background%3Argba%28125%2C125%2C125%2C0.5%29%3B%0A%09cursor%3A%20pointer%3B%0A%09box-sizing%3Acontent-box%3B%0A%7D%0A.custom%20.tp-bullet%3Ahover%2C%0A.custom%20.tp-bullet.selected%20%7B%0A%09background%3Argb%28125%2C125%2C125%29%3B%0A%7D%0A.custom%20.tp-bullet-image%20%7B%0A%7D%0A.custom%20.tp-bullet-title%20%7B%0A%7D%0A%0A");
					var htmlDiv = document.getElementById('rs-plugin-settings-inline-css');
					if(htmlDiv) {
						htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
					}
					else{
						var htmlDiv = document.createElement('div');
						htmlDiv.innerHTML = '<style>' + htmlDivCss + '</style>';
						document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[0]);
					}
				  </script>
				</div><!-- END REVOLUTION SLIDER -->		<!--tc: oildrop_header3_menu -->
		        <div class="header-wrapper header-wrapper-after" id="header-wrapper-after">
        <div class="header header__style3  header-logo-image has-header-row1">

        <div class="header-sticky-height">
            <div class="header__row2 header-sticky">
                <div class="container">
                    <div class="row">

                        <!-- Header Menu -->
						                            <div class="header__menu col-md-12 hidden-sm hidden-xs">
								                                <div class="header__menu-inner">
                                    <div class="menu-strip">
                                        <nav class="main-nav"><ul id="menu-primary-menu" class="menu" style="background-color: #ea822d;"><li id="menu-item-24" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-6 current_page_item menu-item-has-children menu-item-24"><a href="<?php echo site_url(); ?>">Home</a></li>
<li id="menu-item-143" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-143"><a href="<?php echo site_url(); ?>About">About US</a></li>
<li id="menu-item-409" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-409"><a href="javascript:void(0)">Products &amp; Services</a>
<ul class="sub-menu">
	<li id="menu-item-412" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-412"><a href="#">Conveyor Belts & Idler Rollers</a></li>
	<li id="menu-item-412" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-412"><a href="#">Slurry Pumps, Spares & Valves</a></li>
	<li id="menu-item-412" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-412"><a href="#">Flanged Hoses & Rubber Mining Hose</a></li>
	<li id="menu-item-412" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-412"><a href="#">Vibrating Screens & Feeders</a></li>
	<li id="menu-item-412" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-412"><a href="#">Mine Ventilation Systems</a></li>
	<li id="menu-item-412" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-412"><a href="#">HDPE; PVC, Steel & Hydraulic Hoses / Pipes & Fittings</a></li>
</ul>
</li>
<!-- <li id="menu-item-383" class="menu-item menu-item-type-post_type_archive menu-item-object-fw-services menu-item-has-children menu-item-383"><a title="Create a services item" href="javascript:voiid(0)">Services</a>
<ul class="sub-menu">
	<li id="menu-item-384" class="menu-item menu-item-type-post_type menu-item-object-fw-services menu-item-384"><a href="#">Project Design & Engineering Drawings</a></li>
	<li id="menu-item-385" class="menu-item menu-item-type-post_type menu-item-object-fw-services menu-item-385"><a href="#">Pipe, Plant & Infrastructure Construction</a></li>
	<li id="menu-item-386" class="menu-item menu-item-type-post_type menu-item-object-fw-services menu-item-386"><a href="#">Project Management & Consultancy</a></li>
	<li id="menu-item-386" class="menu-item menu-item-type-post_type menu-item-object-fw-services menu-item-386"><a href="#">Bulk Materials Handling - Pumps & Conveyor Surveys</a></li>
	<li id="menu-item-386" class="menu-item menu-item-type-post_type menu-item-object-fw-services menu-item-386"><a href="#">Project Procurement, Warehousing & Freight Logistics</a></li>
	<li id="menu-item-386" class="menu-item menu-item-type-post_type menu-item-object-fw-services menu-item-386"><a href="#">Vibrating Screens / Feeders / Drives & Gearboxes</a></li>
	<li id="menu-item-386" class="menu-item menu-item-type-post_type menu-item-object-fw-services menu-item-386"><a href="#">Coost Engineering</a></li>
	
</ul>
</li> -->
<li id="menu-item-143" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-143"><a href="<?php echo site_url(); ?>Partners">Partners</a></li>
<li id="menu-item-143" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-143"><a href="<?php echo site_url(); ?>News">News &amp; Events</a></li>
<li id="menu-item-22" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-22"><a href="<?php echo site_url(); ?>Contact">Contact US</a></li>
<!-- <li id="menu-item-28" class="marked menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-28"><a href="<?php echo site_url(); ?>Quote">Contact US</a></li> -->
</ul>                                        </nav>
                                    </div><!-- .menu-strip -->
                                </div><!-- .header__menu-inner -->
                            </div><!-- .header__menu -->

                            <!-- Header Buttons -->
							                                <div class="header__buttons col-xs-12 only-mobile-button">
									                                    <div class="header__buttons-wrapper">
                                        <div class="header__buttons-inner">
                                            <ul id="header__buttons-menu" class="header-buttons-menu">
                                                <li class="button-li button-li--mobile-menu">
                                                    <div class="header-button header-button__wrapper">
                                                        <span class="header-button header-button__menu nav-button"></span>
                                                    </div>
                                                </li>
												                                            </ul>
                                        </div><!-- .header__buttons-inner -->
                                    </div><!-- .header__buttons-wrapper -->
                                </div><!-- .header__buttons -->

								
                            </div><!-- .row -->
                        </div><!-- .container -->
                    </div><!-- .header__row2 -->
                </div><!-- .header-sticky-height -->

            </div><!-- .header__style3 -->
        </div><!-- .header-wrapper -->

		
		        <!--tc: /oildrop_header3_menu -->