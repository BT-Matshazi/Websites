<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include "layouts/header.php";

?>


        <!--tc: page.php -->
<div id="page" class="hfeed site homepage unyson-layout unyson-layout-snone snone">
    <a class="skip-link screen-reader-text" href="#content">Skip to content</a>

	
    <div id="content" class="site-content">
		
        <div class="container">

            <div id="primary" class="content-area">
                <main id="main" class="site-main">
                    <div class="post-container snone">
                        <div class="row">
                            <div class="site__content col-xs-12">

								<div class="entry-content__inner">

<div class="entry-content">
	<div class="fw-page-builder-content"><section class="fw-main-row  bg-content-background "
     >
    <span class="bg-image-overlay bg-" style=" "></span>
    <div class="fw-container-fluid unyson_fullwidth">
		        <div class="container has-container">
							<div class="row">
	<div class="col-md-12       " >
    <div style=" margin: ; padding: ;">
	

    <div class="fw-divider__space-40x  "></div>
    </div>
</div>
</div>

<div class="row">
	<div class="col-md-3 to_animate about-us-first-column     col-sm-12 " data-animation="fadeInUp">
    <div style=" margin: ; padding: ;">
	<div class="fw-heading fw-heading--h2    fw-heading--alternate ">
			<h3 class='fw-special__title c-header-textcolor' style='font-weight: 900;color:'><span>Vision</span></h3>	
			
		</div>

    <div class="fw-divider__space-20x  "></div>
    <p>
				To be Africa’s mining, industrial and construction industries procurement and project managers of choice 

			</p>

			<div class="fw-heading fw-heading--h2    fw-heading--alternate ">
			<h3 class='fw-special__title c-header-textcolor' style='font-weight: 900;color:'><span>Mission</span></h3>	
			
		</div>

    <div class="fw-divider__space-20x  "></div>
    <p>
				Achieving Excellence in Project Procurement Management and Installation through Innovation and Efficiency

			</p>

    <a href="<?php echo site_url(); ?>About" target="_self"
       class="fw-btn ">
        <span>More Information</span>
    </a>


    <div class="fw-divider__space-20x  "></div>
    </div>
</div>
<div class="col-md-6 to_animate      col-sm-8 col-xs-12" data-animation="fadeInUp">
    <div style=" margin: ; padding: ;">
	<div class="fw-heading fw-heading--h2    fw-heading--alternate ">
			<h3 class="fw-special__title c-header-textcolor" style="font-weight: 900;"><span>Values</span></h3>	
			
		</div>
<h5 class="fw-special__title c-header-textcolor" style="font-weight:;color:"><span>Solutions</span></h5>
    <div class="fw-divider__space-10x  "></div>
<p>We will provide the solutions for your sourcing, procuring, supply and delivery of mining, industrial and construction equipment within our sphere of expertise.
</p>

    <div class="fw-divider__space-10x  "></div>
    <h5 class="fw-special__title c-header-textcolor" style="font-weight:;color:"><span>Progress</span></h5>
    <div class="fw-divider__space-10x  "></div>
<p>Continuous and swift movement towards realizing our clients and stakeholders goals.
</p>

<div class="fw-divider__space-10x  "></div>
    <h5 class="fw-special__title c-header-textcolor" style="font-weight:;color:"><span>Integrity</span></h5>
    <div class="fw-divider__space-10x  "></div>
<p>Our actions and overall performance will be measured based on truth and transparency, honesty and trust.
</p>


<div class="fw-divider__space-10x  "></div>
    <h5 class="fw-special__title c-header-textcolor" style="font-weight:;color:"><span>Commitment</span></h5>
    <div class="fw-divider__space-10x  "></div>
<p>To deliver on every promise by displaying a “can-do” attitude.
</p>

<div class="fw-divider__space-10x  "></div>
    <h5 class="fw-special__title c-header-textcolor" style="font-weight:;color:"><span>Excellence</span></h5>
    <div class="fw-divider__space-10x  "></div>
<p>We will set the standard in the mining and industrial engineering  procurement, construction and management by doing it quicker, cost effectively and correctly.
</p>



    </div>
</div>
<div class="col-md-3 to_animate      col-sm-4 col-xs-12" data-animation="fadeInUp">
    <div style=" margin: ; padding: ;">
	<div class="fw-heading fw-heading--h5   fw-heading--with-subtitle fw-heading--alternate ">
			<h5 class='fw-special__title c-header-textcolor' style='font-weight:;color:'><span>Edward Battes</span></h5>	        <div class="fw-special__subtitle" style="color: #000;">Managing Director</div>
	</div>

    <div class="fw-divider__space-05x  "></div>
<!-- <p><img class="alignnone size-full wp-image-166" src="http://webdesign-finder.com/oildrop/wp-content/uploads/2016/12/img__about2.png" alt="" width="153" height="52" /></p> -->

    <div class="fw-divider__space-20x  "></div>
    </div>
</div>
</div>

<div class="row">
	<div class="col-md-3 to_animate   hidden-sm     " data-animation="fadeInUp">
    <div style=" margin: ; padding: ;">
	    </div>
</div>
<div class="col-md-3 to_animate about-us-second-column     col-sm-4 col-xs-12" data-animation="fadeInUp">
    <div style=" margin: ; padding: ;">
	    <a href="<?php echo site_url(); ?>About" target="_self"
       class="fw-btn ">
        <span>More Information</span>
    </a>
    </div>
</div>
</div>



				            </div>
			    </div>
</section>





<!-- <section class="fw-main-row  section-bg-image-parallax section-dark-bg bg-accent-color-2 "
    style="background-image:url(http://webdesign-finder.com/oildrop/wp-content/uploads/2016/12/Depositphotos_89065790_original.jpg);background-position: center left top;background-repeat: repeat;background-attachment:scroll;background-size:cover;" >
    <span class="bg-image-overlay bg-accent-color-2" style=" "></span>
    <div class="fw-container-fluid unyson_fullwidth">
		        <div class="container has-container">
							<div class="row">
	<div class="col-md-12       " >
    <div style=" margin: ; padding: ;">
	

    <div class="fw-divider__space-30x  "></div>
    </div>
</div>
</div>



</div>


</div>



				            </div>
			    </div>
</section> -->
<!-- <section class="fw-main-row  "
    style="background-color:#f5f6fb;background-position: center left top;background-repeat: repeat;background-attachment:scroll;background-size:initial;" >
    <span class="bg-image-overlay bg-" style=" "></span>
    <div class="fw-container unyson_content">
		            <div class="container">
								<div class="row">
	<div class="col-md-12       " >
    <div style=" margin: ; padding: ;">
	

    <div class="fw-divider__space-50x  "></div>
    </div>
</div>
</div>

<div class="row">
	<div class=" to_animate    col-lg-3 col-md-12  " data-animation="fadeInUp">
    <div style=" margin: ; padding: ;">
	<div class="fw-heading fw-heading--h2    fw-heading--alternate fw-heading--big-padding">
			<h2 class='fw-special__title c-header-textcolor' style='font-weight:;color:'><span>Testimonials</span></h2>	</div>

    <div class="fw-divider__space-20x  "></div>
    </div>
</div>
<div class=" to_animate    col-lg-9 col-md-12 col-sm-12 " data-animation="fadeInUp">
    <div style=" margin: ; padding: ;">
	<div class="fw-testimonials tm-type1">
	
    <div class="fw-testimonials__list owl-carousel owl-testimonials-5eb19b9a94aa2"
         id="owl-testimonials-5eb19b9a94aa2"
         data-unique_id="5eb19b9a94aa2">
		            <div class="fw-testimonials__item ">
                <div class="fw-testimonials__meta">
                    <div class="fw-testimonials__avatar">
												                            <img src="//webdesign-finder.com/oildrop/wp-content/uploads/2016/12/testimonial-1.jpg"
                                 alt="Sheldon Moreno "/>
						                    </div>
                    <div class="fw-testimonials__author">
                        <span class="fw-testimonials__name">Sheldon Moreno </span>
		                                            <span class="fw-testimonials__job">HEAD OF OPERATIONS</span>
		                                        <span class="fw-testimonials__url">
							<a href=""></a>
						</span>
                    </div>
                </div>
                <div class="fw-testimonials__text">
                    <p>Untrammeled and nothing prevents our being able to do what we like best, every pleasure.</p>
                </div>
            </div>
		            <div class="fw-testimonials__item ">
                <div class="fw-testimonials__meta">
                    <div class="fw-testimonials__avatar">
												                            <img src="//webdesign-finder.com/oildrop/wp-content/uploads/2016/12/team-6.jpg"
                                 alt="Diana Prisiv"/>
						                    </div>
                    <div class="fw-testimonials__author">
                        <span class="fw-testimonials__name">Diana Prisiv</span>
		                                            <span class="fw-testimonials__job">Manager</span>
		                                        <span class="fw-testimonials__url">
							<a href=""></a>
						</span>
                    </div>
                </div>
                <div class="fw-testimonials__text">
                    <p>But in certain circumstances and owing to the claims of duty or the obligations business it will frequently.</p>
                </div>
            </div>
		            <div class="fw-testimonials__item ">
                <div class="fw-testimonials__meta">
                    <div class="fw-testimonials__avatar">
												                            <img src="//webdesign-finder.com/oildrop/wp-content/uploads/2016/12/testimonial-2.jpg"
                                 alt="Mike Banbridge"/>
						                    </div>
                    <div class="fw-testimonials__author">
                        <span class="fw-testimonials__name">Mike Banbridge</span>
		                                            <span class="fw-testimonials__job">CONSULTANT</span>
		                                        <span class="fw-testimonials__url">
							<a href=""></a>
						</span>
                    </div>
                </div>
                <div class="fw-testimonials__text">
                    <p>But in certain circumstances and owing to the claims of duty or the obligations  business it will frequently.</p>
                </div>
            </div>
		            <div class="fw-testimonials__item ">
                <div class="fw-testimonials__meta">
                    <div class="fw-testimonials__avatar">
												                            <img src="//webdesign-finder.com/oildrop/wp-content/uploads/2016/12/testimonial-3.jpg"
                                 alt="Claudia Ortiz"/>
						                    </div>
                    <div class="fw-testimonials__author">
                        <span class="fw-testimonials__name">Claudia Ortiz</span>
		                                            <span class="fw-testimonials__job">CUSTOMER RELATIONS</span>
		                                        <span class="fw-testimonials__url">
							<a href=""></a>
						</span>
                    </div>
                </div>
                <div class="fw-testimonials__text">
                    <p>These cases are perfectly simple and easy to distinguish. In a free hour, our power of choice.</p>
                </div>
            </div>
		            <div class="fw-testimonials__item ">
                <div class="fw-testimonials__meta">
                    <div class="fw-testimonials__avatar">
												                            <img src="//webdesign-finder.com/oildrop/wp-content/uploads/2016/12/team-8.jpg"
                                 alt="John Doe"/>
						                    </div>
                    <div class="fw-testimonials__author">
                        <span class="fw-testimonials__name">John Doe</span>
		                                            <span class="fw-testimonials__job">CHIEF</span>
		                                        <span class="fw-testimonials__url">
							<a href=""></a>
						</span>
                    </div>
                </div>
                <div class="fw-testimonials__text">
                    <p>These cases are perfectly simple and easy to distinguish. In a free hour, our power of choice.</p>
                </div>
            </div>
		            <div class="fw-testimonials__item ">
                <div class="fw-testimonials__meta">
                    <div class="fw-testimonials__avatar">
												                            <img src="//webdesign-finder.com/oildrop/wp-content/uploads/2016/12/team-10.jpg"
                                 alt="Maria Yarosh"/>
						                    </div>
                    <div class="fw-testimonials__author">
                        <span class="fw-testimonials__name">Maria Yarosh</span>
		                                            <span class="fw-testimonials__job">HR</span>
		                                        <span class="fw-testimonials__url">
							<a href=""></a>
						</span>
                    </div>
                </div>
                <div class="fw-testimonials__text">
                    <p>But in certain circumstances and owing to the claims of duty or the obligations  business it will frequently.</p>
                </div>
            </div>
		            <div class="fw-testimonials__item ">
                <div class="fw-testimonials__meta">
                    <div class="fw-testimonials__avatar">
												                            <img src="//webdesign-finder.com/oildrop/wp-content/uploads/2016/12/team-14.jpg"
                                 alt="David Ramsey"/>
						                    </div>
                    <div class="fw-testimonials__author">
                        <span class="fw-testimonials__name">David Ramsey</span>
		                                            <span class="fw-testimonials__job">Partner</span>
		                                        <span class="fw-testimonials__url">
							<a href=""></a>
						</span>
                    </div>
                </div>
                <div class="fw-testimonials__text">
                    <p>These cases are perfectly simple and easy to distinguish. In a free hour, our power of choice.</p>
                </div>
            </div>
		    </div>

</div>

    <div class="fw-divider__space-20x  "></div>
    </div>
</div>
</div>

<div class="row">
	<div class="col-md-12       " >
    <div style=" margin: ; padding: ;">
	

    <div class="fw-divider__space-25x  "></div>
    </div>
</div>
</div>

				        </div>
	    </div>
</section> -->
<section class="fw-main-row  bg-content-background "
     >
    <span class="bg-image-overlay bg-" style=" "></span>
    <div class="fw-container-fluid unyson_fullwidth">
		        <div class="container has-container">
							<div class="row">
	<div class="col-md-12       " >
    <div style=" margin: ; padding: ;">
	

    <div class="fw-divider__space-30x  "></div>
    </div>
</div>
</div>

<div class="row">
	<div class="col-md-3 to_animate      col-sm-12 " data-animation="fadeInUp">
    <div style=" margin: ; padding: ;">
	<div class="fw-heading fw-heading--h2    fw-heading--alternate ">
			<h3 class='fw-special__title c-header-textcolor' style='font-weight:;color:'><span>Feedback</span></h3>	</div>

    <div class="fw-divider__space-20x  "></div>
    </div>
</div>
<div class="col-md-9 to_animate    col-lg-8  col-sm-12 " data-animation="fadeInUp">
    <div style=" margin: ; padding: ;">
	<h5>We’re always interested in new projects, big or small. Please don’t hesitate to get in touch with us regarding your project.</h5><p>If you want to contact us about any issue please call <strong>(+27) 10 220 5401</strong> or <a href="mailto:info@uniflexprojects.co.za"><strong>send us an email</strong></a>. If you would like to submit a proposal for consideration simply <strong><a href="<?php echo site_url(); ?>Contact">contact us</a></strong>.</p>

    <div class="fw-divider__space-30x  "></div>


    </div>
</div>
</div>

				            </div>
			    </div>
</section>
<section class="fw-main-row  section-bg-image-parallax section-dark-bg bg-accent-color-2 "
    style="background-image:url(http://webdesign-finder.com/oildrop/wp-content/uploads/2016/12/Depositphotos_89065790_original.jpg);background-position: center left top;background-repeat: repeat;background-attachment:scroll;background-size:cover;" >
    <span class="bg-image-overlay bg-accent-color-2" style=" "></span>
    <div class="fw-container-fluid unyson_fullwidth">
		        <div class="container has-container">
							<div class="row">
	<div class="col-md-12       " >
    <div style=" margin: ; padding: ;">
	

    <div class="fw-divider__space-30x  "></div>
    </div>
</div>
</div>

<div class="row">
	<div class="col-md-3 to_animate       " data-animation="fadeInUp">
    <div style=" margin: ; padding: ;">
	<div class="fw-heading fw-heading--h2    fw-heading--alternate ">
			<h2 class='fw-special__title c-header-textcolor' style='font-weight:;color:'><span>Newsletter</span></h2>	</div>

    <div class="fw-divider__space-20x  "></div>
    </div>
</div>
<div class="col-md-9 to_animate       " data-animation="fadeInUp">
    <div style=" margin: ; padding: ;">
	<h5>Subscribe to our newsletters to receive latest news and updates</h5><div><script>(function() {
	if (!window.mc4wp) {
		window.mc4wp = {
			listeners: [],
			forms    : {
				on: function (event, callback) {
					window.mc4wp.listeners.push({
						event   : event,
						callback: callback
					});
				}
			}
		}
	}
})();
</script><!-- MailChimp for WordPress v4.3.1 - https://wordpress.org/plugins/mailchimp-for-wp/ --><form id="mc4wp-form-1" class="mc4wp-form mc4wp-form-20" method="post" data-id="20" data-name="Form1" ><div class="mc4wp-form-fields"><p class="mc4wp_with_button_position_absolute">
	<label class="screen-reader-text">Email address: </label>
	<input type="email" name="EMAIL" placeholder="E-mail Address" required />
    <span class="mc4wp_button_position_absolute"><i class="fa fa-envelope-o"></i><input type="submit" value="Subscribe to Newsletter" /></span>
</p></div><label style="display: none !important;">Leave this field empty if you're human: <input type="text" name="_mc4wp_honeypot" value="" tabindex="-1" autocomplete="off" /></label><input type="hidden" name="_mc4wp_timestamp" value="1588698010" /><input type="hidden" name="_mc4wp_form_id" value="20" /><input type="hidden" name="_mc4wp_form_element_id" value="mc4wp-form-1" /><div class="mc4wp-response"></div></form><!-- / MailChimp for WordPress Plugin --></div>

    </div>
</div>
</div>

<div class="row">
	<div class="col-md-12       " >
    <div style=" margin: ; padding: ;">
	

    <div class="fw-divider__space-20x  "></div>
    </div>
</div>
</div>

				            </div>
			    </div>
</section>
<section class="fw-main-row  bg-content-background "
     >
    <span class="bg-image-overlay bg-" style=" "></span>
    <div class="fw-container-fluid unyson_fullwidth">
		        <div class="container has-container">
							<div class="row">
	<div class="col-md-12       " >
    <div style=" margin: ; padding: ;">
	

    <div class="fw-divider__space-10x  "></div>
    </div>
</div>
</div>

<!-- <div class="row">
	<div class="col-md-2 to_animate      col-sm-4 col-xs-6" data-animation="fadeInUp">
    <div style=" margin: ; padding: ;">
	<a class="partner-link partner-link-single" href="javascript:void(0)" target="_blank"><img src="<?php echo base_url(); ?>assets/images/clients/partner-1.png" alt="" /></a>

    <div class="fw-divider__space-10x  "></div>
    </div>
</div>

</div> -->

				            </div>
			    </div>
</section>
<section class="fw-main-row  "
    style="background-color:;background-position: center center;background-repeat: repeat;background-attachment:scroll;background-size:initial;" >
    <span class="bg-image-overlay" style="background-color:; "></span>
    <div class="fw-container-fluid-no unyson_fullwidth">
		            <div class="container">
								<div class="row">
	<div class="col-md-12       " >
    <div style=" margin: ; padding: ;">
	<div class="fw-map" data-locations="[{&quot;title&quot;:&quot;Location title&quot;,&quot;url&quot;:&quot;&quot;,&quot;thumb&quot;:false,&quot;coordinates&quot;:{&quot;lat&quot;:-26.034288,&quot;lng&quot;:27.9914263},&quot;description&quot;:&quot;Location Description&quot;}]" data-map-type="ROADMAP" data-map-height="350" data-gmap-key="AIzaSyC0pr5xCHpaTGv12l73IExOHDJisBP2FK4" data-disable-scrolling=""      data-template-uri="">
    <div class="fw-map-canvas"></div>
</div>    </div>
</div>
</div>

				        </div>
	    </div>
</section>
<section class="fw-main-row  section-dark-bg bg-accent-color-2 "
     >
    <span class="bg-image-overlay bg-" style=" "></span>
    <div class="fw-container-fluid unyson_fullwidth">
		        <div class="container has-container">
							<div class="row">
	<div class="col-md-3       " >
    <div style=" margin: ; padding: ;">
	

    <div class="fw-divider__space-20x  "></div>
<!-- <span class="unyson-media-image"><img src="http://webdesign-finder.com/oildrop/wp-content/uploads/2017/01/logo_alt-452x128.png" alt="http://webdesign-finder.com/oildrop/wp-content/uploads/2017/01/logo_alt-452x128.png" width="452" height="128" /></span> -->

    <div class="fw-divider__space-10x  "></div>
<p><h4>Design | Define | Deliver</h4><div class="shortcode-widget-area ">	<aside id="oildrop_unyson_social-3" class="widget_social_links col-md-12 col-sm-12 widget widget_oildrop_unyson_social">    <div class="wrap-social">
	    <ul>
		            <li>
                <a href="https://www.facebook.com/uniflexprojects/?__tn__=%2Cd%2CP-R&eid=ARD4BK3_VZtAc2rBDtSRqkSy_OokSiYvzRv_pSEKT0pRzpNh4Xw2LsS0ZUNpZii-W04VzC5JYXsO5tF_" class="btn-share" target="_blank" style="border: none;">
                    <i class="fa-facebook" style="color: #fff;"></i>
                </a>
            </li>
		            <li>
                <a href="https://twitter.com/uniflexprojects" class="btn-share" target="_blank" style="border: none;">
                    <i class="fa-twitter" style="color: #fff;"></i>
                </a>
            </li>
		            <!-- <li>
                <a href="javascript:void(0)" class="btn-share" target="_blank" style="border: none;">
                    <i class="fa-linkedin" style="color: #fff;"></i>
                </a>
            </li> -->
		    </ul>
    </div>
	</aside></div>
    </div>
</div>
<div class="col-md-6       " >
    <div style=" margin: ; padding: ;">
	

    <div class="fw-divider__space-30x  hidden-lg hidden-md "></div>
<div class="shortcode-widget-area  overflow-visible"><aside id="text-3" class="col-md-12 col-sm-12 widget widget_text">			<div class="textwidget"><div><div role="form" class="wpcf7" id="wpcf7-f415-p6-o1" lang="en-US" dir="ltr">
<div class="screen-reader-response"></div>
<form action="/oildrop/#wpcf7-f415-p6-o1" method="post" class="wpcf7-form" novalidate="novalidate">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="415" />
<input type="hidden" name="_wpcf7_version" value="5.0.5" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f415-p6-o1" />
<input type="hidden" name="_wpcf7_container_post" value="6" />
</div>
<div class="oildrop-getaquote" id="getaquote">
<h2>Request A quote</h2>
<div class="row">
<div class="col-md-6">
<div class="fields"><span class="wpcf7-form-control-wrap your-name"><input type="text" name="your-name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Your Name (Required)" /></span></div>
<div class="fields"><span class="wpcf7-form-control-wrap your-email"><input type="email" name="your-email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" aria-required="true" aria-invalid="false" placeholder="Your Email (Required)" /></span></div>
<div class="fields"><span class="wpcf7-form-control-wrap your-phone"><input type="text" name="your-phone" value="" size="40" class="wpcf7-form-control wpcf7-text" aria-invalid="false" placeholder="Your Phone Number" /></span></div>
<div class="fields"><span class="wpcf7-form-control-wrap your-company"><input type="text" name="your-company" value="" size="40" class="wpcf7-form-control wpcf7-text" aria-invalid="false" placeholder="Company Name" /></span></div>
<div class="fields"><span class="wpcf7-form-control-wrap your-subject"><input type="text" name="your-subject" value="" size="40" class="wpcf7-form-control wpcf7-text" aria-invalid="false" placeholder="Project Title" /></span></div>
</div>
<div class="col-md-6">
<div class="fields"><span class="wpcf7-form-control-wrap your-message"><textarea name="your-message" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea" aria-invalid="false" placeholder="Your Requirements"></textarea></span></div>
<div class="fields submit"><input type="submit" value="Request a Quote" class="wpcf7-form-control wpcf7-submit" /></div>
</div>
</div>
</div>
<div class="wpcf7-response-output wpcf7-display-none"></div></form></div></div></div>
		</aside></div>

    <div class="fw-divider__space  clear"
         style="margin-top: 1px;"></div>

    </div>
</div>
<div class="col-md-3       " >
    <div style=" margin: ; padding: ;">
	

    <div class="fw-divider__space-20x  "></div>
<div class="fw-iconbox clearfix fw-iconbox--left ib-type2">
    <div class="fw-iconbox__image ">
        <a href="">            <i class="fa fa-phone" style="border: none;"></i>        </a>
    </div>
    <div class="fw-iconbox__aside">
        <div class="fw-iconbox__title">
            <h3 style="color: #333;">A phone call from one of</h3>
        </div>
		            <div class="fw-iconbox__text">
                <div>Our consultants</div>
            </div>
		    </div>
</div>

    <div class="fw-divider__space-10x  "></div>
<div class="fw-iconbox clearfix fw-iconbox--left ib-type2">
    <div class="fw-iconbox__image ">
        <a href="">            <i class="fa fa-money" style="border: none;"></i>        </a>
    </div>
    <div class="fw-iconbox__aside">
        <div class="fw-iconbox__title">
            <h3 style="color: #333;">Evaluation of</h3>
        </div>
		            <div class="fw-iconbox__text">
                <div>Your project cost</div>
            </div>
		    </div>
</div>

    <div class="fw-divider__space-10x  "></div>
<div class="fw-iconbox clearfix fw-iconbox--left ib-type2">
    <div class="fw-iconbox__image ">
        <a href="">            <i class="fa fa-comments-o" style="border: none;"></i>        </a>
    </div>
    <div class="fw-iconbox__aside">
        <div class="fw-iconbox__title">
            <h3 style="color: #333;">An in-person meeting to</h3>
        </div>
		            <div class="fw-iconbox__text">
                <div>Discuss the details </div>
            </div>
		    </div>
</div>

    <div class="fw-divider__space-10x  "></div>
<div class="fw-iconbox clearfix fw-iconbox--left ib-type2">
    <div class="fw-iconbox__image ">
        <a href="">            <i class="fa fa-lock" style="border: none;"></i>        </a>
    </div>
    <div class="fw-iconbox__aside">
        <div class="fw-iconbox__title">
            <h3 style="color: #333;">Details are protected,</h3>
        </div>
		            <div class="fw-iconbox__text">
                <div>Privacy guaranteed</div>
            </div>
		    </div>
</div>    </div>
</div>
</div>

				            </div>
			    </div>
</section>
</div>
    <div class="clear"></div>
</div><!-- .entry-content -->



</div><!-- .entry-content__inner -->                            </div>

							
                        </div>
                    </div>

                </main><!-- .site-main -->
            </div><!-- .content-area -->
        </div><!-- .container -->

		<!--tc: footer -->
<div id="to-top" class="to-top"><i class="fa fa-angle-up"></i></div>
</div><!-- .site-content -->



</div><!-- .site -->

<?php include "layouts/footer.php" ?>