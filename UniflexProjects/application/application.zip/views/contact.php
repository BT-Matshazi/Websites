<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include "layouts/header.php";

?>
<!--tc: page.php -->
<div id="page" class="hfeed site unyson-layout unyson-layout-snone">
    <a class="skip-link screen-reader-text" href="#content">Skip to content</a>

            <div class="entry-header-wrapper"
             style="background-image: url()">
            <div class="container">
                <header class="entry-header"><h1 class="page-title"><span>Contact Us</span></h1>
        <!-- <div class="breadcrumbs breadcrumbs-items-2">
                                    <span class="first-item">
                                    <a href="http://webdesign-finder.com/oildrop/">Homepage</a></span>
                                <span class="separator separator-0">&gt;</span>
                                                    <span class="last-item">Contacts</span>
                        </div> -->
                </header><!-- .entry-header -->
            </div>
        </div><!-- .entry-header-wrapper -->
    <div id="content" class="site-content">
        
        <div class="container">

            <div id="primary" class="content-area">
                <main id="main" class="site-main">
                    <div class="post-container snone">
                        <div class="row">
                            <div class="site__content col-xs-12">

                                <div class="entry-content__inner">

<div class="entry-content">
    <div class="fw-page-builder-content"><!-- <section class="fw-main-row  "
    style="background-color:;background-position: center center;background-repeat: repeat;background-attachment:scroll;background-size:initial;" >
    <span class="bg-image-overlay" style="background-color:; "></span>
    <div class="fw-container-fluid-no unyson_fullwidth">
                    <div class="container">
                                <div class="row">
    <div class="col-md-12       " >
    <div style=" margin: ; padding: ;">
    <div class="fw-map" data-locations="[{&quot;title&quot;:&quot;Location title&quot;,&quot;url&quot;:&quot;&quot;,&quot;thumb&quot;:false,&quot;coordinates&quot;:{&quot;lat&quot;:40.7127837,&quot;lng&quot;:-74.0059413},&quot;description&quot;:&quot;Location Description&quot;}]" data-map-type="ROADMAP" data-map-height="350" data-gmap-key="AIzaSyC0pr5xCHpaTGv12l73IExOHDJisBP2FK4" data-disable-scrolling=""      data-template-uri="http://webdesign-finder.com/oildrop/wp-content/themes/oildrop">
    <div class="fw-map-canvas"></div>
</div>    </div>
</div>
</div>

                        </div>
        </div>
</section> -->
<section class="fw-main-row  bg-content-background "
     >
    <span class="bg-image-overlay bg-" style=" "></span>
    <div class="fw-container-fluid unyson_fullwidth">
                <div class="container has-container">
                            <div class="row">
    <div class="col-md-12       " >
    <div style=" margin: ; padding: ;">
    

    <div class="fw-divider__space-40x  "></div>
    </div>
</div>
</div>

<div class="row">
    <div class="col-md-8       " >
    <div style=" margin: ; padding: ;">
    <div class="fw-heading fw-heading--h2    fw-heading--alternate ">
            <h2 class='fw-special__title c-header-textcolor' style='font-weight:;color:'><span>Leave Us A Message</span></h2> </div>

    <div class="fw-divider__space-20x  "></div>
<div class="shortcode-widget-area "><aside id="text-2" class="col-md-12 col-sm-12 widget widget_text">          <div class="textwidget"><div><div role="form" class="wpcf7" id="wpcf7-f29-p14-o1" lang="en-US" dir="ltr">
<div class="screen-reader-response"></div>
<form action="/oildrop/contacts/#wpcf7-f29-p14-o1" method="post" class="wpcf7-form" novalidate="novalidate">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="29" />
<input type="hidden" name="_wpcf7_version" value="5.0.5" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f29-p14-o1" />
<input type="hidden" name="_wpcf7_container_post" value="14" />
</div>
<div class="row">
<div class="col-md-6">
<div class="fields"><span class="wpcf7-form-control-wrap your-name"><input type="text" name="your-name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Your Name" /></span></div>
</div>
<div class="col-md-6">
<div class="fields"><span class="wpcf7-form-control-wrap your-subject"><input type="text" name="your-subject" value="" size="40" class="wpcf7-form-control wpcf7-text" aria-invalid="false" placeholder="Subject" /></span></div>
</div>
</div>
<div class="row">
<div class="col-md-6">
<div class="fields"><span class="wpcf7-form-control-wrap your-phone"><input type="text" name="your-phone" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Your Phone Number" /></span></div>
</div>
<div class="col-md-6">
<div class="fields"><span class="wpcf7-form-control-wrap your-email"><input type="email" name="your-email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" aria-required="true" aria-invalid="false" placeholder="Your Email" /></span></div>
</div>
</div>
<div class="fields"><span class="wpcf7-form-control-wrap your-message"><textarea name="your-message" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea" aria-invalid="false" placeholder="Your Message"></textarea></span></div>
<div class="fields submit"><input type="submit" value="Send Message" class="wpcf7-form-control wpcf7-submit" /></div>
<div class="wpcf7-response-output wpcf7-display-none"></div></form></div></div></div>
        </aside></div>


    <div class="fw-divider__space-40x  "></div>
    </div>
</div>
<div class="col-md-4       " >
    <div style=" margin: ; padding: ;">
    <div class="fw-heading fw-heading--h2    fw-heading--alternate ">
            <h2 class='fw-special__title c-header-textcolor' style='font-weight:;color:'><span>Contact info</span></h2> </div>

    <div class="fw-divider__space-20x  "></div>
<div class="fw-iconbox clearfix fw-iconbox--left ib-type1">
    <div class="fw-iconbox__image ">
        <a href="">            <i class="fa fa-map-marker"></i>        </a>
    </div>
    <div class="fw-iconbox__aside">
        <div class="fw-iconbox__title">
            <h3>South Africa</h3>
        </div>
                    <div class="fw-iconbox__text">
                <div>15 FALCON LANE, <br>
                DOUGLASDALE EXT 49 <br>Sandton, <br> 2191, <br>Johannesburg </div>
            </div>
            </div>


</div>

    <div class="fw-divider__space-10x  "></div>
<div class="fw-iconbox clearfix fw-iconbox--left ib-type1">
    <div class="fw-iconbox__image ">
        <a href="">            <i class="fa fa-mobile"></i>        </a>
    </div>
    <div class="fw-iconbox__aside">
        <div class="fw-iconbox__title">
            <h3></h3>
        </div>
                    <div class="fw-iconbox__text">
                <div>
<strong>+27 10 220 5401</strong></div>
            </div>
            </div>
</div>

   <div class="fw-divider__space-20x  "></div>
<div class="fw-iconbox clearfix fw-iconbox--left ib-type1">
    <div class="fw-iconbox__image ">
        <a href="">            <i class="fa fa-map-marker"></i>        </a>
    </div>
    <div class="fw-iconbox__aside">
        <div class="fw-iconbox__title">
            <h3>Zimbabwe</h3>
        </div>
                    <div class="fw-iconbox__text">
                <div>06 TRAILL ROAD, <br>
                MOUNT PLEASANT
 <br>HARARE</div>
            </div>
            </div>

            
</div>
  <div class="fw-divider__space-10x  "></div>
<div class="fw-iconbox clearfix fw-iconbox--left ib-type1">
    <div class="fw-iconbox__image ">
        <a href="">            <i class="fa fa-mobile"></i>        </a>
    </div>
    <div class="fw-iconbox__aside">
        <div class="fw-iconbox__title">
            <h3></h3>
        </div>
                    <div class="fw-iconbox__text">
                <div>
<strong>+263 4 301 645 <br>+263 86 4422 1975
 </strong></div>
            </div>
            </div>
</div>

    <div class="fw-divider__space-10x  "></div>
<div class="fw-iconbox clearfix fw-iconbox--left ib-type1">
    <div class="fw-iconbox__image ">
        <a href="">            <i class="fa fa-at"></i>        </a>
    </div>
    <div class="fw-iconbox__aside">
        <div class="fw-iconbox__title">
            <h3></h3>
        </div>
                    <div class="fw-iconbox__text">
                <div>Email<br>
<span>  info@uniflexprojects.co.za</span></div>
            </div>
            </div>
</div>

    <div class="fw-divider__space-40x  "></div>
    </div>
</div>
</div>

                            </div>
                </div>
</section>
</div>
    <div class="clear"></div>
</div><!-- .entry-content -->



</div><!-- .entry-content__inner -->                            </div>

                            
                        </div>
                    </div>

                </main><!-- .site-main -->
            </div><!-- .content-area -->
        </div><!-- .container -->

        <!--tc: footer -->
<div id="to-top" class="to-top"><i class="fa fa-angle-up"></i></div>
</div><!-- .site-content -->


<?php include "layouts/footer.php" ?>
